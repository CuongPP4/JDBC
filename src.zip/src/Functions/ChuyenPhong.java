package Functions;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import database.JDBCUtil;


public class ChuyenPhong {
	private static Connection con = JDBCUtil.getConnection();
	private static Validator validator= new Validator();
	private static Scanner sc = new Scanner(System.in);
	public static void hienThiKhachHangTungPhong(Connection con) throws SQLException {
		PreparedStatement prStmt = null;
		ResultSet rs = null;

		prStmt = con.prepareStatement(
				"SELECT p.maPhong, dp.maDatPhong, kh.maKH, kh.tenKH, kh.SDT, kh.CCCD, sd.truongPhong\r\n"
						+ "FROM PHONG p\r\n" + "INNER JOIN CHITIETDATPHONG cdp ON p.maPhong = cdp.maPhong\r\n"
						+ "INNER JOIN DATPHONG dp ON cdp.maDatPhong = dp.maDatPhong\r\n"
						+ "INNER JOIN SUDUNGPHONG sd ON cdp.maChiTiet = sd.maChiTiet\r\n"
						+ "INNER JOIN KHACHHANG kh ON sd.maKH = kh.maKH\r\n" + "ORDER BY p.maPhong, dp.maDatPhong;");

		try {
			rs = prStmt.executeQuery();
			while (rs.next()) {
				String maPhong= rs.getString("maPhong");
				String maDatPhong=rs.getString("maDatPhong");
				String maKH=rs.getString("maKH");
				String tenKH=rs.getString("tenKH");
				String SDT=rs.getString("SDT");
				String CCCD=rs.getString("CCCD");
				Byte truongPhong=rs.getByte("truongPhong");
	
				System.out.println("\t maPhong=" + maPhong + "\t maDatPhong=" + maDatPhong + "\t maKH=" + maKH + "\t tenKH="
						+ tenKH + "\t SDT=" + SDT + "\t CCCD=" + CCCD + "\t truongPhong=" + truongPhong + "]");
				
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prStmt != null) {
					prStmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	// KET THUC FUNCTION HIEN THI KHACH HANG TUNG PHONG
	
	// UPDATE TRƯỞNG PHÒNG
	public void doiTruongPhong(int maChiTiet) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String maKHTP="";

		ps = con.prepareStatement(
				"SELECT S.maChiTiet, P.maPhong, KH.maKH, KH.tenKH, KH.SDT, KH.CCCD, S.truongPhong FROM KHACHHANG KH, PHONG P, CHITIETDATPHONG C, SUDUNGPHONG S \r\n"
						+ "WHERE S.maChiTiet = ? AND P.maPhong = C.maPhong AND C.maChiTiet = S.maChiTiet AND S.maKH = KH.maKH;");
		ps.setInt(1, maChiTiet);
		rs = ps.executeQuery();

		while (rs.next()) {
			int maCT = rs.getInt("maChiTiet");
			String maPhong = rs.getString("maPhong");
			String maKH = rs.getString("maKH");
			String tenKH = rs.getString("tenKH");
			String sdt = rs.getString("SDT");
			String cccd = rs.getString("CCCD");
			String truongPhong = rs.getString("truongPhong");

			System.out.println("Mã phong: " + maPhong + "\tMã Chi Tiet: " + maCT + "\tMã khách hàng: " + maKH
					+ "\tTên khách hàng: " + tenKH + "\tSố điện thoại: " + sdt + "\tCCCD: " + cccd + "\tTruong Phong: "
					+ truongPhong);
		}

		do {
		System.out.print("Nhap Ma Khach Hang của Truong Phong moi: ");
		maKHTP = sc.nextLine();
		}while(validator.checkDoiTruongPhong(maKHTP, maChiTiet, con));

		ps = con.prepareStatement("UPDATE SUDUNGPHONG\r\n" + "SET truongPhong = \r\n" + "    CASE \r\n"
				+ "        WHEN maKH = ? THEN 1\r\n" + "        ELSE 0\r\n" + "    END\r\n" + "WHERE maChiTiet = ?;");
		ps.setString(1, maKHTP);
		ps.setInt(2, maChiTiet);
		int row = ps.executeUpdate();
		if (row > 0)
			System.out.println("Đã cập nhật trưởng phòng mới.");
		else
			System.out.println("Cập nhật thất bại");

		rs.close();
		ps.close();

	}

	//UPDATE THÀNH TIỀN
	public void setThanhTien(String maPhong, int maChiTiet, Connection con) throws SQLException {
		System.out.println(maPhong + "   " + maChiTiet);
		String sql = "UPDATE CHITIETDATPHONG SET thanhTien = DATEDIFF(DAY,ngayCheckIn,ngayCheckOut)*(SELECT Distinct gia FROM PHONG P , CHITIETDATPHONG CT, LOAIPHONG LP\r\n"
				+ "WHERE P.maLoaiPhong = LP.maLoaiPhong AND CT.maPhong = P.maPhong AND P.maPhong = ?) WHERE maChiTiet = ?;";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maPhong);
		ps.setInt(2, maChiTiet);
		int check = ps.executeUpdate();
		if(check>0) {
			System.out.println("Đã cập nhật tiền cho phòng "+maPhong);
		}
		ps.close();
	}
	
	// FUNTION CHUYỂN PHÒNG
	public void chuyenPhong() throws SQLException {
		int point = 0;
		boolean check= true;
		while (check) {
			System.out.println("_________________________________________________________");
			System.out.println("1. ĐỔI PHÒNG CHO NHAU. ");
			System.out.println("2. CHUYỂN ĐẾN PHÒNG NGƯỜI KHÁC. ");
			System.out.println("3. CHUYỂN SANG PHÒNG MỚI. ");
			System.out.println("4. THOÁT. ");

			System.out.println();

			try {
				System.out.println("Mời bạn chọn chức năng: ");
				point = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Vui lòng chọn đúng !");
				continue;
			}

			switch (point) {
			case 1:
				// Đổi phòng cho nhau
				PreparedStatement ps1 = null;
				String khachHang2="", khachHang1="";
				ResultSet rs1 = null;
				String maDP1="";
				try {
					
					// Nhập tên khách hàng thứ 1
					do {
					System.out.print("Nhap mã khach hang thu 1: ");
					khachHang1 = sc.nextLine();
					}while(validator.checkMaKH3(khachHang1, con));
					
					// Lấy mã đặt phòng
					ps1 = con.prepareStatement("SELECT CHITIETDATPHONG.maDatPhong as maDatPhong FROM SUDUNGPHONG, CHITIETDATPHONG\r\n"
							+ "WHERE SUDUNGPHONG.maChiTiet= CHITIETDATPHONG.maChiTiet AND SUDUNGPHONG.maKH =?;");
					ps1.setString(1, khachHang1);
					rs1= ps1.executeQuery();
					while(rs1.next()) {
						maDP1= rs1.getString("maDatPhong");
					}
					
					// Hiển thị khách hàng cùng mã đặt phòng
					ps1 = con.prepareStatement("SELECT KHACHHANG.tenKH,CHITIETDATPHONG.maPhong, DATPHONG.maDatPhong as maDatPhong,SUDUNGPHONG.maKH FROM KHACHHANG,CHITIETDATPHONG, DATPHONG,SUDUNGPHONG\r\n"
							+ "WHERE  CHITIETDATPHONG.maDatPhong= DATPHONG.maDatPhong \r\n"
							+ "AND CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet AND KHACHHANG.maKH= SUDUNGPHONG.maKH AND  DATPHONG.maDatPhong=?  ;");
					ps1.setString(1, maDP1);
					rs1= ps1.executeQuery();
					while(rs1.next()) {
						String tenKH= rs1.getString("tenKH");
						String maPhong = rs1.getString("maPhong");
						String maDatPhong = rs1.getString("maDatPhong");
						String maKhachHang = rs1.getString("maKH");
						System.out.println("tenKH: "+tenKH+"\tmaPhong: "+maPhong+"\tmaDatPhong: "+maDatPhong+"\tmaKhachHang: "+maKhachHang);
						
					}
					
					// Nhập tên khách hàng thứ 2
					do {
					System.out.print("Nhap mã khach hang thu 2: ");
					khachHang2 = sc.nextLine();
					}while(validator.checkMaKH2(maDP1, khachHang2,khachHang1, con));

					ps1 = con.prepareStatement("SELECT maChiTiet, truongPhong FROM SUDUNGPHONG WHERE maKH = ?");
					ps1.setString(1, khachHang1);
					rs1 = ps1.executeQuery();
					rs1.next();
					int maChiTiet1 = rs1.getInt("maChiTiet");
					byte truongPhong1 = rs1.getByte("truongPhong");

					ps1 = con.prepareStatement("SELECT maChiTiet, truongPhong FROM SUDUNGPHONG WHERE maKH = ?");
					ps1.setString(1, khachHang2);
					rs1 = ps1.executeQuery();
					rs1.next();
					int maChiTiet2 = rs1.getInt("maChiTiet");
					byte truongPhong2 = rs1.getByte("truongPhong");

					// Đổi mã chi tiết của hai khách hàng cho nhau
					ps1 = con.prepareStatement("UPDATE SUDUNGPHONG SET maChiTiet = ? WHERE maKH = ?");
					ps1.setInt(1, maChiTiet2);
					ps1.setString(2, khachHang1);
					ps1.executeUpdate();

					ps1 = con.prepareStatement("UPDATE SUDUNGPHONG SET maChiTiet = ? WHERE maKH = ?");
					ps1.setInt(1, maChiTiet1);
					ps1.setString(2, khachHang2);
					ps1.executeUpdate();

					doiTruongPhong(maChiTiet1);

					doiTruongPhong(maChiTiet2);

					// Close connections
					rs1.close();
					ps1.close();

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					if (rs1 != null) {
						try {
							rs1.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
					if (ps1 != null) {
						try {
							ps1.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				}

				break;
			case 2:
				// CHUYỂN SANG PHÒNG NGƯỜI KHÁC
				PreparedStatement ps2 = null;
				ResultSet rs2 = null;
				String maDP="",maKhachHang="",maKhachDP="",maP="";
				
				do {
				System.out.print("Nhập mã của khách hàng đặt phòng: ");
				maKhachDP = sc.nextLine();
				}while(validator.checkMaKHDP(maKhachDP, con));
				
				ps2= con.prepareStatement("SELECT maDatPhong from DATPHONG where maKH=?;");
				ps2.setString(1, maKhachDP);
				rs2 = ps2.executeQuery();
				while(rs2.next()) {
					maDP = rs2.getString("maDatPhong");
				}

				// Hiển thị danh sách các phòng có thể chuyển sang
				try {
					System.out.print("----Danh Sach Phong Co The Chuyen---\n ");

					ps2 = con.prepareStatement(
							"SELECT CHITIETDATPHONG.maChiTiet,PHONG.maPhong, PHONG.soLuongToiDa, COUNT(*) as soLuongKhach\r\n"
									+ "FROM PHONG\r\n"
									+ "JOIN CHITIETDATPHONG ON PHONG.maPhong = CHITIETDATPHONG.maPhong\r\n"
									+ "JOIN SUDUNGPHONG ON CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet\r\n"
									+ "JOIN DATPHONG ON CHITIETDATPHONG.maDatPhong = DATPHONG.maDatPhong\r\n"
									+ "WHERE DATPHONG.maDatPhong = ?\r\n"
									+ "GROUP BY CHITIETDATPHONG.maChiTiet, PHONG.maPhong, PHONG.soLuongToiDa\r\n"
									+ "HAVING COUNT(*) < PHONG.soLuongToiDa;");
					ps2.setString(1, maDP);
					rs2 = ps2.executeQuery();
					int count = 0;

					while (rs2.next()) {
						String maPhong = rs2.getString("maPhong");
						int soLuongToiDa = rs2.getInt("soLuongToiDa");
						int soLuongKhach = rs2.getInt("soLuongKhach");
						count++;
						System.out.println("\t Mã phong: " + maPhong + "\t So Khach Toi Da: " + soLuongToiDa
								+ "\tSo Luong Khach: " + soLuongKhach);

					}
					;
					if (count == 0) {
						System.out.println("Không có phòng trống nào.");
					} else {
						int maChiTiet = 0;
						int maChiTietChuyenPhong = 0;
						String maPhongCu = "";
						
						do {
						System.out.println("Nhập mã khách hàng muốn chuyển phòng:");
						maKhachHang = sc.nextLine();
						}while(validator.checkMaKH1(maKhachHang,maDP, con));

						// Lấy mã chi tiết của phòng cũ
						ps2 = con.prepareStatement("SELECT maChiTiet as maChiTiet FROM SUDUNGPHONG WHERE maKH=?;");
						ps2.setString(1, maKhachHang);
						rs2 = ps2.executeQuery();
						while (rs2.next()) {
							maChiTiet = rs2.getInt("maChiTiet");
						};
						

						// Lấy mã phòng cũ
						ps2 = con.prepareStatement("SELECT maPhong FROM CHITIETDATPHONG WHERE maChiTiet=?;");
						ps2.setInt(1, maChiTiet);
						rs2 = ps2.executeQuery();
						while (rs2.next()) {
							maPhongCu = rs2.getString("maPhong");
						}
						;

						// Kiểm tra xem phòng hiện tại có nhiều hơn 1 khách đang ở

						ps2 = con.prepareStatement(
								"SELECT CHITIETDATPHONG.maChiTiet as maChiTiet,PHONG.maPhong, PHONG.soLuongToiDa, COUNT(*) as soLuongKhach\r\n"
										+ "FROM PHONG\r\n"
										+ "JOIN CHITIETDATPHONG ON PHONG.maPhong = CHITIETDATPHONG.maPhong\r\n"
										+ "JOIN SUDUNGPHONG ON CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet\r\n"
										+ "JOIN DATPHONG ON CHITIETDATPHONG.maDatPhong = DATPHONG.maDatPhong\r\n"
										+ "WHERE DATPHONG.maDatPhong = ? and CHITIETDATPHONG.maPhong=?\r\n"
										+ "GROUP BY CHITIETDATPHONG.maChiTiet, PHONG.maPhong, PHONG.soLuongToiDa\r\n"
										+ "HAVING COUNT(*) =1;");
						System.out.println("madp=" + maDP);
						System.out.println("maPhongCu=" + maPhongCu);

						ps2.setString(1, maDP);
						ps2.setString(2, maPhongCu);
						rs2 = ps2.executeQuery();
						if (rs2.next()) {
							// Cập nhật checkout cho phòng cũ
							ps2 = con.prepareStatement(
									"UPDATE CHITIETDATPHONG SET ngayCheckOut = GETDATE()\r\n" + "WHERE maChiTiet = ?");
							ps2.setInt(1, maChiTiet);
							ps2.executeUpdate();

							// Cập nhật thành tiền cho phòng cũ

							setThanhTien(maPhongCu, maChiTiet, con);

							// Cập nhật trạng thái phòng cũ
							ps2 = con.prepareStatement("UPDATE PHONG SET trangThai = 'False' WHERE maPhong = ?");
							ps2.setString(1, maPhongCu);
							ps2.executeUpdate();
						}
						
						do {
						System.out.print("Nhap Ma Phong muon chuyen den: ");
						maP = sc.nextLine();
						}while(validator.checkMaPhong(maDP, maP, con));

						ps2 = con.prepareStatement(
								"SELECT maChiTiet as maChiTiet FROM CHITIETDATPHONG WHERE maPhong=?;");
						ps2.setString(1, maP);
						rs2 = ps2.executeQuery();
						while (rs2.next()) {
							maChiTietChuyenPhong = rs2.getInt("maChiTiet"); // Lấy mã chi tiết phòng muốn chuyển đến
						}
						;

						ps2 = con.prepareStatement("UPDATE SUDUNGPHONG SET maChiTiet = ? WHERE maKH = ?"); // Cập nhật mã chi tiết mới cho khách hàng		
						ps2.setInt(1, maChiTietChuyenPhong);
						ps2.setString(2, maKhachHang);
						ps2.executeUpdate();
						doiTruongPhong(maChiTietChuyenPhong);

						// Xóa sử dụng phòng
						ps2 = con.prepareStatement("DELETE FROM SUDUNGPHONG WHERE maChiTiet=? and maKH=?;");
						ps2.setInt(1, maChiTiet);
						ps2.setString(2, maKhachHang);
						ps2.executeUpdate();

						rs2.close();
						ps2.close();
					}
				} catch (Exception e) {
					e.printStackTrace();

				} finally {
					if (rs2 != null) {
						try {
							rs2.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
					if (ps2 != null) {
						try {
							ps2.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				}

				break;
			case 3:
				// Chuyển sang phòng mới

				String maPhongMoi = "";
				String maPhongCu = "";
				String maDatPhong = "";
				String maKH;
				int maChiTiet = 0;
				ResultSet rs3 = null;
				Date checkOut = null;
				PreparedStatement ps3 = null;

				try {

					// Hiển thị những phòng đang trống
					ps3 = con.prepareStatement("SELECT *FROM PHONG WHERE trangThai='True';");

					rs3 = ps3.executeQuery();
					int count2 = 0;
					while (rs3.next()) {
						String maPhong = rs3.getString("maPhong");
						String maLoaiPhong = rs3.getString("maLoaiPhong");
						byte trangThai = rs3.getByte("trangThai");
						String moTa = rs3.getString("moTa");
						int soLuongToiDa = rs3.getInt("soLuongToiDa");
						count2++;
						System.out.println("\t Mã phong: " + maPhong + "\tmaLoaiPhong : " + maLoaiPhong
								+ "\ttrangThai: " + trangThai + "\tmoTa: " + moTa + "\t soLuongToiDa " + soLuongToiDa);
					}
					;

					// Kiểm tra xem có phòng trống không
					if (count2 == 0) {
						System.out.println("Không còn phòng trống nào");
					} else {

						// Nhập mã phòng muốn chuyển
						do {
						System.out.print("Nhập mã phòng muốn chuyển: ");
						maPhongMoi = sc.nextLine();
						}while(validator.checkMaPhongTrong(maPhongMoi, con));

						// Nhập thông tin khách hàng chuyển phòng
						do {
						System.out.print("Nhap mã khách hàng cần chuyển phòng: ");
						maKH = sc.nextLine();
						}while(validator.checkMaKHSuDungPhong(maKH, con));

						// Lấy mã phòng cũ
						String query5 = "SELECT maPhong,DATPHONG.maDatPhong as maDatPhong,SUDUNGPHONG.maKH, CHITIETDATPHONG.ngayCheckOut as checkOut FROM CHITIETDATPHONG, DATPHONG,SUDUNGPHONG\r\n"
								+ "WHERE  SUDUNGPHONG.maKH =? AND CHITIETDATPHONG.maDatPhong= DATPHONG.maDatPhong \r\n"
								+ "AND CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet ;";

						PreparedStatement ps5 = con.prepareStatement(query5);
						ps5.setString(1, maKH);
						ResultSet rs5 = ps5.executeQuery();
						while (rs5.next()) {
							maPhongCu = rs5.getString("maPhong");
							maDatPhong = rs5.getString("maDatPhong");
							checkOut = rs5.getDate("checkOut");
						}
						;

						// Lấy mã chi tiết của phòng cũ
						String query6 = "SELECT maChiTiet FROM CHITIETDATPHONG WHERE maDatPhong = ? AND maPhong = ?";
						PreparedStatement ps6 = con.prepareStatement(query6);
						ps6.setString(1, maDatPhong);
						ps6.setString(2, maPhongCu);
						rs3 = ps6.executeQuery();

						while (rs3.next()) {
							maChiTiet = rs3.getInt("maChiTiet");
						}
						;
						System.out.println("maChiTiet" + maChiTiet + " maKH=" + maKH);

						// Lấy ra mã chi tiết cuối cùng
						String query7 = "SELECT TOP 1 maChiTiet FROM CHITIETDATPHONG ORDER BY maChiTiet DESC";
						PreparedStatement ps7 = con.prepareStatement(query7);
						ResultSet rs7 = ps7.executeQuery();

						// Lấy giá trị maChiTiet cuối cùng
						int maChiTietCuoi = 0;
						if (rs7.next()) {
							maChiTietCuoi = rs7.getInt("maChiTiet");
						}

						// Kiểm tra phòng cũ có phải chỉ có 1 khách đang sử dụng
						ps3 = con.prepareStatement(
								"SELECT CHITIETDATPHONG.maChiTiet as maChiTiet,PHONG.maPhong, PHONG.soLuongToiDa, COUNT(*) as soLuongKhach\r\n"
										+ "FROM PHONG\r\n"
										+ "JOIN CHITIETDATPHONG ON PHONG.maPhong = CHITIETDATPHONG.maPhong\r\n"
										+ "JOIN SUDUNGPHONG ON CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet\r\n"
										+ "JOIN DATPHONG ON CHITIETDATPHONG.maDatPhong = DATPHONG.maDatPhong\r\n"
										+ "WHERE DATPHONG.maDatPhong = ? and CHITIETDATPHONG.maPhong=?\r\n"
										+ "GROUP BY CHITIETDATPHONG.maChiTiet, PHONG.maPhong, PHONG.soLuongToiDa\r\n"
										+ "HAVING COUNT(*) =1;");
						ps3.setString(1, maDatPhong);
						ps3.setString(2, maPhongCu);
						ResultSet rs8 = ps3.executeQuery();
						if (rs8.next()) {
							// Cập nhật checkout cho phòng cũ
							ps3 = con.prepareStatement(
									"UPDATE CHITIETDATPHONG SET ngayCheckOut = GETDATE()\r\n" + "WHERE maChiTiet = ?");
							ps3.setInt(1, maChiTiet);
							ps3.executeUpdate();

							// Cập nhật thành tiền cho phòng cũ

							setThanhTien(maPhongCu, maChiTiet, con);

							// Cập nhật trạng thái của phòng cũ
							ps3 = con.prepareStatement("UPDATE PHONG SET trangThai = 1 WHERE maPhong = ?");
							ps3.setString(1, maPhongCu);
							ps3.executeUpdate();					

						}

						// Thêm chi tiết mới cho phòng mới
						ps3 = con.prepareStatement(
								"INSERT INTO CHITIETDATPHONG (maChiTiet, maDatPhong, maPhong, ngayCheckIn, ngayCheckOut, trangThai) VALUES (?, ?, ?, GETDATE(), ?, 1)\r\n"
										+ "");
						ps3.setInt(1, maChiTietCuoi + 1);
						ps3.setString(2, maDatPhong);
						ps3.setString(3, maPhongMoi);
						ps3.setDate(4, checkOut);
						ps3.executeUpdate();

						// Cập nhật trạng thái của phòng mới
						ps3 = con.prepareStatement("UPDATE PHONG SET trangThai = 0 WHERE maPhong = ?");
						ps3.setString(1, maPhongMoi);
						ps3.executeUpdate();

						// Cập nhật thành tiền cho phòng mới

						setThanhTien(maPhongMoi, maChiTietCuoi + 1, con);

						// Xóa sử dụng phòng
						ps3 = con.prepareStatement("DELETE FROM SUDUNGPHONG WHERE maChiTiet=? and maKH=?;");
						ps3.setInt(1, maChiTiet);
						ps3.setString(2, maKH);
						ps3.executeUpdate();

						// Cập nhật trạng thái của khách hàng
						ps3 = con.prepareStatement(
								"UPDATE SUDUNGPHONG SET truongPhong = 0 WHERE maChiTiet = ? AND maKH = ?");
						ps3.setInt(1, maChiTiet);
						ps3.setString(2, maKH);
						ps3.executeUpdate();
						ps3 = con.prepareStatement(
								"INSERT INTO SUDUNGPHONG (maChiTiet, maKH, truongPhong) VALUES (?, ?, 1)");
						ps3.setInt(1, maChiTietCuoi + 1);
						ps3.setString(2, maKH);
						ps3.executeUpdate();

					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("loi");
				}

				break;
			case 4:
				check=false;
				break;

			default:
				System.out.println("Nhập sai, vui lòng nhập lại");
				break;
			}
		}

	}



}
