package Functions;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Validate {
	public int checkCuPhap(int begin, int end, Scanner scanner) {
		int phim;
		boolean check = false;
		do {
			try {
				if (check)
					System.out.println("CÚ PHÁP CỦA BẠN KHÔNG ĐÚNG, MỜI NHẬP LẠI:");
				phim = Integer.parseInt(scanner.nextLine());
			} catch (NumberFormatException e) {
				phim = 0;
			}
			check = true;
		} while (phim < begin || phim > end);
		return phim;

	}

	public String checkMaKH(String displayScreen, Scanner scanner) {
		System.out.println(displayScreen);
		String maKH = scanner.nextLine();
		boolean validate = maKH.matches("KH\\d{3}");
		while (!validate) {
			System.out.println("NHẬP SAI FORMAT (KHxxx), MỜI NHẬP LẠI:");
			maKH = scanner.nextLine();
		}
		return maKH;
	}

	public boolean existMaKH(String maKH, Connection con) throws SQLException {
		String sql = "SELECT maKH FROM KHACHHANG WHERE maKH = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maKH);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return true;
		}
		return false;
	}

	public String checkMaDP(String displayScreen, Scanner scanner) {
		System.out.println(displayScreen);
		String maDP = scanner.nextLine();
		while (!(maDP.matches("^DP\\d{3}$"))) {
			System.out.println("NHẬP SAI FORMAT (DPxxx), MỜI NHẬP LẠI:");
			maDP = scanner.nextLine();
		}
		return maDP;
	}

	public boolean existMaDP(String maDP, Connection con) throws SQLException {
		String sql = "SELECT maDatPhong FROM DATPHONG WHERE maDatPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maDP);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return true;
		}
		rs.close();
		ps.close();
		return false;
	}

	public String checkMaP(String displayScreen, Scanner scanner) {
		System.out.println(displayScreen);
		String maPhong = scanner.nextLine();
		while (!(maPhong.matches("^P\\d{3}$"))) {
			System.out.println("NHẬP SAI FORMAT (Pxxx), MỜI NHẬP LẠI:");
			maPhong = scanner.nextLine();
		}
		return maPhong;
	}

	public boolean maPhongBooked(String maP, Connection con) throws SQLException {
		String sql = "SELECT maPhong FROM CHITIETDATPHONG WHERE maPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maP);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return true;
		}
		rs.close();
		ps.close();
		return false;
	}

	public String checkMaLP(String displayScreen, Scanner scanner) {
		System.out.println(displayScreen);
		String maLP = scanner.nextLine();
		while (!(maLP.matches("^LP\\d{2}$"))) {
			System.out.println("NHẬP SAI FORMAT (LPxx), MỜI NHẬP LẠI:");
			maLP = scanner.nextLine();
		}
		return maLP;
	}

	public boolean existMaLP(String maLP, Connection con) throws SQLException {
		String sql = "SELECT maLoaiPhong FROM LOAIPHONG WHERE maLoaiPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maLP);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return true;
		}
		rs.close();
		ps.close();
		return false;
	}

	public String checkNumberPhone(Scanner scanner, String displayScreen) {
		System.out.println(displayScreen);
		String input = scanner.nextLine();
		while (!(input.matches("^LP\\d{2}$"))) {
			System.out.print("Bạn đã nhập sai, mời bạn nhập lại: ");
			input = scanner.nextLine();
		}
		return input;

	}

	public Integer checkInt(String status, int begin, int end, Scanner scanner) {
		int bien;
		try {
			System.out.println(status);
			bien = Integer.parseInt(scanner.nextLine());
		} catch (NumberFormatException e) {
			bien = -1;
		}
		while (bien < begin || bien > end) {
			try {
				System.out.println("BẠN ĐÃ NHẬP QUÁ SỐ, MỜI NHẬP LẠI:");
				bien = Integer.parseInt(scanner.nextLine());
			} catch (NumberFormatException e) {
				bien = -1;
			}
		}
		return bien;
	}

	public Date checkDate(String message, Scanner scanner) {
		do {
			try {
				System.out.println(message);
				LocalDate date = LocalDate.parse(scanner.nextLine());
				LocalDate minDate = LocalDate.of(1, 1, 1);
				if (date.isBefore(minDate)) {
					System.out.println("KHÔNG ĐƯỢC NHẬP NGÀY ÂM");
				} else if (date.getMonthValue() == 2 && date.lengthOfMonth() > YearMonth.now().lengthOfMonth()) {
					System.out.println("THÁNG 2 CỦA NĂM HIỆN TẠI CHỈ CÓ " + YearMonth.now().lengthOfMonth() + " NGÀY");
				} else {
					return Date.valueOf(date);
				}
			} catch (DateTimeParseException e) {
				System.out.println("VUI LÒNG NHẬP ĐÚNG FORMAT YYYY-MM-DD");
			}
		} while (true);
	}

}
