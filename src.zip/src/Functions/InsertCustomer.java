package Functions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class InsertCustomer {
	ChuyenPhong chuyenPhong = new ChuyenPhong();
	
	public static String getNextCode(int codeN) { 
		DecimalFormat df = new DecimalFormat("000"); 
		String code = df.format(codeN); 
		codeN++; return code;
		}

	public void insertCustomer(Connection con) throws SQLException {

		Scanner sc = new Scanner(System.in);
		PreparedStatement ps = null;
		ResultSet rs = null;
		String maDatPhong = "DP";
		int soLuong = 0;

		try {
			System.out.println("---NHAP THONG TIN KHACH HANG DATPHONG---");
			System.out.println("Nhap Ten Khach Hang");
			String tenKHDP = sc.nextLine();
			System.out.println("Nhap So Dien Thoai Khach Hang");
			String SDTDP = sc.nextLine();
			System.out.println("Nhap CCCD Khach Hang");
			String CCCDDP = sc.nextLine();

			ps = con.prepareStatement("SELECT COUNT(maKH) as soLuong FROM KHACHHANG;");
			rs = ps.executeQuery();
			while (rs.next()) {
				soLuong = rs.getInt("soLuong");
			}
			String maKHDP = "KH";
			maKHDP += (getNextCode(soLuong+1));
			ps = con.prepareStatement("INSERT INTO KHACHHANG (maKH, tenKH, SDT, CCCD) VALUES " + "(?, ?, ?, ?);");
			ps.setString(1, maKHDP);
			ps.setString(2, tenKHDP);
			ps.setString(3, SDTDP);
			ps.setString(4, CCCDDP);
			int rowsInserted = ps.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("Nhap thanh cong!");
			} 	

			// Lay ma dat phong cuoi cung
			ps = con.prepareStatement("SELECT COUNT(maDatPhong) soLuong FROM DATPHONG;\r\n");
			rs = ps.executeQuery();
			while (rs.next()) {
				soLuong = rs.getInt("soLuong");
			}
			maDatPhong += (getNextCode(soLuong+1));

			// Nhap so luong khach va so luong phong

			System.out.println("Nhap so luong khach");
			int soLuongKhach = Integer.parseInt(sc.nextLine());
			int demKhach = soLuongKhach - 1;
			System.out.println("Nhap so luong phong");
			int soLuongPhong = Integer.parseInt(sc.nextLine());
			int demPhong = soLuongPhong;

			// insert vao bang DATPHONG
			ps = con.prepareStatement(
					" INSERT INTO DATPHONG (maDatPhong, maKH, ngayDat, soLuongKhach, soLuongPhong) VALUES\r\n"
							+ "(?, ?, GETDATE(), ?, ?);");
			ps.setString(1, maDatPhong);
			ps.setString(2, maKHDP);
			ps.setInt(3, soLuongKhach);
			ps.setInt(4, soLuongPhong);
			ps.executeUpdate();
			boolean kt = true;

			while (demKhach > 0) {
				String maPhong = "";

				while (demPhong > 0) {
					// Hien thi phong con trong
					ps = con.prepareStatement("SELECT *FROM PHONG WHERE trangThai='False';");

					rs = ps.executeQuery();
					int count2 = 0;
					while (rs.next()) {
						String maP = rs.getString("maPhong");
						String maLoaiPhong = rs.getString("maLoaiPhong");
						byte trangThai = rs.getByte("trangThai");
						String moTa = rs.getString("moTa");
						int soLuongToiDa = rs.getInt("soLuongToiDa");
						count2++;
						System.out.println("\t Mã phong: " + maP + "\tmaLoaiPhong : " + maLoaiPhong + "\ttrangThai: "
								+ trangThai + "\tmoTa: " + moTa + "\t soLuongToiDa " + soLuongToiDa);
					}
					;

					System.out.println("Nhap ma phong:");
					maPhong = sc.nextLine();

					System.out.println("Nhap ngay checkOut (YYYY-MM-DD): ");
					String checkOut = "";
					java.sql.Date sqlCheckOut;
					do {
						try {
							checkOut = sc.nextLine();
							DateFormat df = new SimpleDateFormat("YYYY-MM-DD");
							df.setLenient(false);
							Date dt = df.parse(checkOut);
							sqlCheckOut = new java.sql.Date(dt.getTime());
							break;
						} catch (Exception e) {
							System.out.println("Vui long nhap lai");
						}
					} while (true);

					// Lấy mã chi tiết cuoi
					String query7 = "SELECT TOP 1 maChiTiet FROM CHITIETDATPHONG ORDER BY maChiTiet DESC";
					PreparedStatement ps7 = con.prepareStatement(query7);
					ResultSet rs7 = ps7.executeQuery();
					int maChiTietCuoi = 0;
					if (rs7.next()) {
						maChiTietCuoi = rs7.getInt("maChiTiet");
					}

					// Nhap bang CHITIETDATPHONG

					ps = con.prepareStatement(
							" INSERT INTO CHITIETDATPHONG (maChiTiet, maDatPhong, maPhong, ngayCheckIn, ngayCheckOut, thanhTien, trangThai) VALUES\r\n"
									+ "(?, ?, ?, GETDATE(), ?);");
					ps.setInt(1, maChiTietCuoi + 1);
					ps.setString(2, maDatPhong);
					ps.setString(3, maPhong);
					ps.setDate(4, sqlCheckOut);
					ps.executeUpdate();

					// Lay so luong toi da cua phong
					int soLuongToiDaP = 0;
					ps = con.prepareStatement("SELECT soLuongToiDa FROM PHONG WHERE maPhong=?;");
					ps.setString(1, maPhong);
					rs = ps.executeQuery();
					while (rs.next()) {
						soLuongToiDaP = rs.getInt("soLuongToiDa");
					}
					boolean kt2 = true;
					int demk = 0;
					int soKhach;

					do {
						System.out.println("Nhap so khach phong " + maPhong);
						soKhach = Integer.parseInt(sc.nextLine());
						if (soKhach < soLuongToiDaP)
							kt2 = false;
						else
							System.out.println("Nhap so luong khach < " + soLuongToiDaP);
					} while (kt2);

					// Lay phong cho nguoi dat phong
					if (kt) {
						ps = con.prepareStatement(
								" INSERT INTO SUDUNGPHONG(maChiTiet, maKH, truongPhong) VALUES\r\n" + "(?, ?,1);");
						ps.setInt(1, maChiTietCuoi + 1);
						ps.setString(2, maKHDP);
						soKhach = soKhach - 1;
						kt = false;
						int rowsInserted2 = ps.executeUpdate();
						if (rowsInserted2 > 0) {
							System.out.println("Nhap thanh cong cho khach dat phong!");
						}
					}

					while (soKhach > 0) {
						String maKH = "KH";
						System.out.println("---NHAP THONG TIN KHACH HANG ---");
						System.out.println("Nhap Ten Khach Hang");
						String tenKH = sc.nextLine();
						System.out.println("Nhap So Dien Thoai Khach Hang");
						String SDT = sc.nextLine();
						System.out.println("Nhap CCCD Khach Hang");
						String CCCD = sc.nextLine();

						ps = con.prepareStatement("SELECT COUNT(maKH) as soLuong FROM KHACHHANG;");
						rs = ps.executeQuery();
						while (rs.next()) {
							soLuong = rs.getInt("soLuong");
						}
						maKH += (soLuong + 1);
						ps = con.prepareStatement(
								" INSERT INTO KHACHHANG (maKH, tenKH, SDT, CCCD) VALUES " + "(?, ?, ?, ?);");
						ps.setString(1, maKH);
						ps.setString(2, tenKH);
						ps.setString(3, SDT);
						ps.setString(4, CCCD);

						int rowsInserted3 = ps.executeUpdate();
						if (rowsInserted3 > 0) {
							System.out.println("Nhap thanh cong!");
						}

						ps = con.prepareStatement(
								" INSERT INTO SUDUNGPHONG(maChiTiet, maKH, truongPhong) VALUES\r\n" + "(?, ?,0);");
						ps.setInt(1, maChiTietCuoi + 1);
						ps.setString(2, maKH);
						ps.executeUpdate();
						demKhach--;
						soKhach--;

					}
					ps = con.prepareStatement("UPDATE PHONG SET trangThai = 'True' WHERE maPhong = ?");
					ps.setString(1, maPhong);
					ps.executeUpdate();

					chuyenPhong.doiTruongPhong(maChiTietCuoi + 1);

					demPhong--;

				}
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			// Closing the resources
			try {
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}


}
