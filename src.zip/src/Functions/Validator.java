package Functions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Validator {
	public boolean checkDoiTruongPhong(String maKhachHang, int maChiTiet, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement(
				"SELECT KH.maKH FROM KHACHHANG KH, PHONG P, CHITIETDATPHONG C, SUDUNGPHONG S	WHERE S.maChiTiet = ? AND P.maPhong = C.maPhong AND C.maChiTiet = S.maChiTiet AND S.maKH = KH.maKH AND KH.maKH =? GROUP BY KH.maKH;");
		ps.setInt(1, maChiTiet);
		ps.setString(2, maKhachHang);
		rs = ps.executeQuery();
		if (rs.next()) {
			return false;
		} else {
			System.out.println("Mã Khách Hàng không Đúng, Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaKH(String maDatPhong, String maKhachHang, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement("SELECT SUDUNGPHONG.maKH FROM KHACHHANG,CHITIETDATPHONG, DATPHONG,SUDUNGPHONG\r\n"
				+ "WHERE  CHITIETDATPHONG.maDatPhong= DATPHONG.maDatPhong \r\n"
				+ "AND CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet AND KHACHHANG.maKH= SUDUNGPHONG.maKH AND  DATPHONG.maDatPhong=? AND SUDUNGPHONG.maKH =?;");
		ps.setString(1, maDatPhong);
		ps.setString(2, maKhachHang);
		rs = ps.executeQuery();
		if (rs.next()) {
			return false;
		} else {
			System.out.println("Mã Khách Hàng không phù hợp. Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaKH1(String maKhachHang, String maDatPhong, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement("SELECT SUDUNGPHONG.maKH FROM KHACHHANG,CHITIETDATPHONG, DATPHONG,SUDUNGPHONG\r\n"
				+ "WHERE  CHITIETDATPHONG.maDatPhong= DATPHONG.maDatPhong \r\n"
				+ "AND CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet AND KHACHHANG.maKH= SUDUNGPHONG.maKH AND SUDUNGPHONG.maKH =? AND CHITIETDATPHONG.maDatPhong=?;");
		ps.setString(1, maKhachHang);
		ps.setString(2, maDatPhong);
		rs = ps.executeQuery();
		if (rs.next()) {
			System.out.println("vào vòng");
			return false;
		} else {
			System.out.println("Mã Khách Hàng không phù hợp. Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaKH3(String maKhachHang, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement("SELECT SUDUNGPHONG.maKH FROM KHACHHANG,CHITIETDATPHONG, DATPHONG,SUDUNGPHONG\r\n"
				+ "WHERE  CHITIETDATPHONG.maDatPhong= DATPHONG.maDatPhong \r\n"
				+ "AND CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet AND KHACHHANG.maKH= SUDUNGPHONG.maKH AND SUDUNGPHONG.maKH =? ;");
		ps.setString(1, maKhachHang);
		rs = ps.executeQuery();
		if (rs.next()) {
			System.out.println("vào vòng");
			return false;
		} else {
			System.out.println("Mã Khách Hàng không phù hợp. Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaKH2(String maDatPhong, String maKhachHang2, String maKhachHang1, Connection con)
			throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		ps = con.prepareStatement("SELECT SUDUNGPHONG.maKH FROM KHACHHANG,CHITIETDATPHONG, DATPHONG,SUDUNGPHONG\r\n"
				+ "WHERE  CHITIETDATPHONG.maDatPhong= DATPHONG.maDatPhong \r\n"
				+ "AND CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet AND KHACHHANG.maKH= SUDUNGPHONG.maKH AND  DATPHONG.maDatPhong=? AND SUDUNGPHONG.maKH =?;");
		ps.setString(1, maDatPhong);
		ps.setString(2, maKhachHang2);
		rs = ps.executeQuery();
		if (maKhachHang2.equals(maKhachHang1)) {
			System.out.println("Mã khách hàng bị trùng lặp. Vui lòng nhập lại.");
			return true;
		}
		if (rs.next()) {
			return false;
		} else {
			System.out.println("Mã Khách Hàng không phù hợp. Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaKHDP(String maKhachHang, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement("SELECT maDatPhong from DATPHONG where maKH=?;");
		ps.setString(1, maKhachHang);
		rs = ps.executeQuery();
		if (rs.next()) {
			return false;
		} else {
			System.out.println("Khách hàng này không có trong danh sách đặt phòng. Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaPhong(String maDatPhong, String maPhong, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement("SELECT PHONG.maPhong as maPhong, PHONG.soLuongToiDa, COUNT(*) as soLuongKhach\r\n"
				+ "FROM PHONG\r\n"
				+ "JOIN CHITIETDATPHONG ON PHONG.maPhong = CHITIETDATPHONG.maPhong\r\n"
				+ "JOIN SUDUNGPHONG ON CHITIETDATPHONG.maChiTiet = SUDUNGPHONG.maChiTiet\r\n"
				+ "JOIN DATPHONG ON CHITIETDATPHONG.maDatPhong = DATPHONG.maDatPhong\r\n"
				+ "WHERE DATPHONG.maDatPhong = ? AND PHONG.maPhong=?\r\n"
				+ "GROUP BY CHITIETDATPHONG.maChiTiet, PHONG.maPhong, PHONG.soLuongToiDa\r\n"
				+ "HAVING COUNT(*) < PHONG.soLuongToiDa;");
		ps.setString(1, maDatPhong);
		ps.setString(2, maPhong);
		rs = ps.executeQuery();
		if (rs.next()) {
			return false;
		} else {
			System.out.println("Mã phòng không đúng. Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaPhongTrong(String maPhong, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement("SELECT maPhong FROM PHONG WHERE trangThai=1 and maPhong = ?;");
		ps.setString(1, maPhong);
		rs = ps.executeQuery();
		if (rs.next()) {
			return false;
		} else {
			System.out.println("Mã phòng không đúng. Vui lòng nhập lại.");
			return true;

		}

	}

	public boolean checkMaKHSuDungPhong(String maKH, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;

		ps = con.prepareStatement("SELECT maKH FROM SUDUNGPHONG WHERE maKH=?;");
		ps.setString(1, maKH);
		rs = ps.executeQuery();
		if (rs.next()) {
			return false;
		} else {
			System.out.println("Mã khách hàng không đúng. Vui lòng nhập lại.");
			return true;

		}

	}

}
