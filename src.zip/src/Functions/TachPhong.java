package Functions;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TachPhong {

	public int countTachPhong(String maPhong, Connection con) throws SQLException {
		String sql = "SELECT COUNT(maChiTiet) soKhach FROM SuDungPhong WHERE "
				+ "maChiTiet = (SELECT maChiTiet FROM ChiTietDatPhong WHERE maPhong = ?) "
				+ "GROUP BY maChiTiet";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maPhong);
		ResultSet rs = ps.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("soKhach");
		}
		rs.close();
		ps.close();
		return count;
	}
	
	public int maChiTietTach (String maPhong, Connection con) throws SQLException {
		String sql = "SELECT maChiTiet FROM ChiTietDatPhong WHERE maPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maPhong);
		ResultSet rs = ps.executeQuery();
		int maChiTiet = 0;
		if (rs.next()) {
			maChiTiet = rs.getInt("maChiTiet");
		}
		rs.close();
		ps.close();
		return maChiTiet;
	}
	
	public Date getCheckIn(String maDatPhong, Connection con) throws SQLException {
		String sql = "SELECT ngayCheckIn FROM ChiTietDatPhong WHERE maDatPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maDatPhong);
		ResultSet rs = ps.executeQuery();
		Date checkIn = null;
		if (rs.next()) {
			checkIn = rs.getDate("ngayCheckIn");
		}
		ps.close();
		rs.close();
		return checkIn;
	}
	
	public void deleteCT (int maChiTiet, Connection con) throws SQLException {
		String sql = "DELETE FROM ChiTietDatPhong WHERE maChiTiet = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, maChiTiet);
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}
	
	public void deleteSD (String maKH, Connection con) throws SQLException {
		String sql = "DELETE FROM SuDungPhong WHERE maKH = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maKH);
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}
	
	public void showPhongTach (String maDatPhong, Connection con) throws SQLException {
		String sql = "SELECT maPhong, maKH FROM SuDungPhong SD, ChiTietDatPhong CT WHERE "
				+ "SD.maChiTiet = CT.maChiTiet AND maDatPHong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maDatPhong);
		ResultSet rs = ps.executeQuery();
		String maPhong = null;
		String maKH = null;
		System.out.println("M� KH" + "\t" + "\t" + "M� Ph�ng");
		while (rs.next()) {
			maPhong = rs.getString("maPhong");
			maKH = rs.getString("maKH");
			System.out.println(maPhong + "\t" + "|" + "\t" + maKH);
		}
		rs.close();
		ps.close();
	}
	
	public int countMaCT(int maChiTiet, Connection con) throws SQLException {
		String sql = "SELECT COUNT(maChiTiet) demCT FROM SuDungPhong WHERE maChiTiet = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, maChiTiet);
		ResultSet rs = ps.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("demCT");
		}
		rs.close();
		ps.close();
		return count;
	}
	
	public List<String> getMaKH(int maChiTiet, Connection con) throws SQLException {
		String sql = "SELECT maKH FROM SuDungPhong WHERE maChiTiet = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, maChiTiet);
		ResultSet rs = ps.executeQuery();
		List<String> list = new ArrayList<String>();
		String maKH = null;
		while (rs.next()) {
			maKH = rs.getString("maKH");
			list.add(maKH);
		}
		rs.close();
		ps.close();
		return list;
	}
	
	public boolean checkPhong(String maPhong, Connection con) throws SQLException {
		String sql = "SELECT maPhong FROM CHITIETDATPHONG WHERE maPhong = ? AND trangThai = 'False'";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maPhong);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return true;
		}
		return false;
	}
	
	public List<String> RoomForCount (int count, Connection con) throws SQLException {
		String sql = "SELECT maPhong FROM LOAIPHONG LP, PHONG P "
				+ "WHERE trangThai = 'False' AND soLuongToiDa >= ? AND LP.maLoaiPhong = P.maLoaiPhong";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, count);
		ResultSet rs = ps.executeQuery();
		List<String> list = new ArrayList<String>();
		while (rs.next()) {
			String maPhong = rs.getString("maPhong");
			list.add(maPhong);
		}
		ps.close();
		rs.close();
		return list;
	}
	
}
















