package Functions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import database.JDBCUtil;
import model.KhachHang;


public class QuanLyKhachHang {
	// SELECT toàn bộ dữ liệu table của database
	public static List<KhachHang> getALL(Connection con) throws SQLException {
		List<KhachHang> list = new ArrayList<KhachHang>();
		String sql = "SELECT * FROM KHACHHANG";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		KhachHang kh = new KhachHang();
		while (rs.next()) {
			kh = new KhachHang();
			kh.setMaKH(rs.getString("maKH"));
			kh.setTenKH(rs.getNString("tenKH"));
			kh.setSdt(rs.getString("sdt"));
			kh.setCCCD(rs.getString("CCCD"));
			list.add(kh);
		}
		ps.close();
		rs.close();
		return list;
	}

	// SELECT Thông tin KHÁCH HÀNG Theo 1 mã KH

	public static ArrayList<KhachHang> getALLmaKH(String maKH) throws SQLException {
		ArrayList<KhachHang> list = new ArrayList<KhachHang>();
		Connection connection = JDBCUtil.getConnection();
		KhachHang kh = new KhachHang();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM KHACHHANG WHERE maKH = ?";
		ps = connection.prepareStatement(sql);
		ps.setString(1, maKH);
		rs = ps.executeQuery();
		while (rs.next()) {
			kh = new KhachHang(rs.getString("maKH"), rs.getString("tenKH"), rs.getString("sdt"), rs.getString("CCCD"));
			list.add(kh);
		}
		return list;
	}

	// SELECT Thông tin KHÁCH HÀNG Theo 1 SoDT
	public static ArrayList<KhachHang> getALLSDT(String sdt) throws SQLException {
		ArrayList<KhachHang> list = new ArrayList<KhachHang>();
		Connection connection = JDBCUtil.getConnection();
		KhachHang kh = new KhachHang();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM KHACHHANG WHERE SDT = ?";
		ps = connection.prepareStatement(sql);
		ps.setString(1, sdt);
		rs = ps.executeQuery();
		while (rs.next()) {
			kh = new KhachHang(rs.getString("maKH"), rs.getString("tenKH"), rs.getString("sdt"), rs.getString("CCCD"));
			list.add(kh);
		}
		return list;
	}

	// SELECT Thông tin KHÁCH HÀNG Theo 1 CCCD
	public static ArrayList<KhachHang> getALLCCCD(String cccd) throws SQLException {
		ArrayList<KhachHang> list = new ArrayList<KhachHang>();
		Connection connection = JDBCUtil.getConnection();
		KhachHang kh = new KhachHang();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM KHACHHANG WHERE CCCD = ?";
		ps = connection.prepareStatement(sql);
		ps.setString(1, cccd);
		rs = ps.executeQuery();
		while (rs.next()) {
			kh = new KhachHang(rs.getString("maKH"), rs.getString("tenKH"), rs.getString("sdt"), rs.getString("CCCD"));
			list.add(kh);
		}
		return list;
	}

	// Insert Thông tin khách hàng vào database
	public static String insertKhachHang(KhachHang kh) {
		Connection connection = JDBCUtil.getConnection();
		String sql = "INSERT INTO KHACHHANG VALUES (?,?,?,?)";
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setString(1, kh.getMaKH());
			ps.setString(2, kh.getTenKH());
			ps.setString(3, kh.getSdt());
			ps.setString(4, kh.getCCCD());
			if (ps.executeUpdate() == 0) {
				return "Insert Thất Bại";
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
			return "Insert Thất Bại";
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return "Insert Thành Công";
	}

	// UPDATE TOTAL thông tin khách hàng
	public static void getUpdateALL(String maKH, String tenKH, String SDT, String CCCD) {
		Connection connection = JDBCUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "UPDATE KHACHHANG SET tenKH = ?, SDT = ?, CCCD = ? WHERE maKH = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, tenKH);
			ps.setString(2, SDT);
			ps.setString(3, CCCD);
			ps.setString(4, maKH);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// UPDATE Tên khách hàng theo maKH
	public static void getUpdateTENKH(String maKH, String tenKH) {
		Connection connection = JDBCUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "UPDATE KHACHHANG SET tenKH = ? WHERE maKH = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, tenKH);
			ps.setString(2, maKH);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// UPDATE SDT theo maKH
	public static void getUpdateSDT(String maKH, String sdt) {
		Connection connection = JDBCUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "UPDATE KHACHHANG SET sdt = ? WHERE maKH = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, sdt);
			ps.setString(2, maKH);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// UPDATE CCCD theo maKH
	public static void getUpdateCCCD(String maKH, String cccd) {
		Connection connection = JDBCUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "UPDATE KHACHHANG SET CCCD = ? WHERE maKH = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cccd);
			ps.setString(2, maKH);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void getdeleteKH(String maKH, Connection connection) throws SQLException {
		String sql = "DELETE FROM KHACHHANG WHERE maKH = ? ";
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, maKH);
		if (ps.executeUpdate() > 0) {
			System.out.println("Thanh Cong");
		} else {
			System.out.println("Thai bai");
		}
		ps.close();
	}


	public static boolean checkExistmaKH(String maKH) throws SQLException {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				conn = JDBCUtil.getConnection();
				String sql = "Select * From KHACHHANG where maKH = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, maKH);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
		} while (true);
	}

	public static boolean checkExistSDT(String sdt) throws SQLException {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				conn = JDBCUtil.getConnection();
				String sql = "Select * From KHACHHANG where SDT = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, sdt);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
		} while (true);
	}

	public static boolean checkExistCCCD(String cccd) throws SQLException {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				conn = JDBCUtil.getConnection();
				String sql = "Select * From KHACHHANG where CCCD = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, cccd);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
		} while (true);
	}

}
