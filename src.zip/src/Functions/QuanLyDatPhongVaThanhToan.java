package Functions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class QuanLyDatPhongVaThanhToan {
	private static Scanner scanner = new Scanner(System.in);
	public void addmaKH(Connection connection) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;


		// Lấy dữ liệu từ bàn phím
		System.out.print("MOI NHAP MA DAT PHONG (CHI NHAP CAC CHU SO CUOI): ");
		String maDatPhong = scanner.nextLine();

		// Kiểm tra mã đặt phòng có trùng nhau không

		String checkMaDatPhong = "SELECT COUNT(*) FROM DATPHONG WHERE maDatPhong = ?";
		pstmt = conn.prepareStatement(checkMaDatPhong);
		pstmt.setString(1, "DP" + maDatPhong);
		ResultSet rs = pstmt.executeQuery();
		int count = 0;
		while (rs.next()) {
			count = rs.getInt(1);
		}
		while (!maDatPhong.matches("^[0-9]{3,4}$") || count > 0) {
			if (!maDatPhong.matches("^[0-9]{3,4}$")) {
				System.out.print("MA DAT PHONG KHONG HOP LE. VUI LONG NHAP LAI!: ");
			} else {
				System.out.print("MA DAT PHONG DA TON TAI. VUI LONG NHAP LAI!: ");
			}
			maDatPhong = scanner.nextLine();
			pstmt.setString(1, "DP" + maDatPhong);
			rs = pstmt.executeQuery();
			count = 0;
			while (rs.next()) {
				count = rs.getInt(1);
			}
		}

		System.out.print("NHAP MA KHACH HANG DAI DIEN (CHI NHAP CAC CHU SO CUOI): ");
		String maKH = scanner.nextLine();
		while (!maKH.matches("^[0-9]{3,4}$")) {
			System.out.print("MA KHACH HANG DAI DIEN KHONG HOP LE. VUI LONG NHAP LAI!: ");
			maKH = scanner.nextLine();
		}
		System.out.print("NHAP NGAY DAT (yyyy/MM/dd): ");
		String ngayDatStr = scanner.nextLine();
		// Kiểm tra số nhập vào có là số nguyên
		int soLuongKhach = 0;
		int soLuongPhong = 0;

		do {
			try {
				System.out.print("NHAP SO LUONG KHACH: ");
				String input = scanner.nextLine();
				if (!input.matches("\\d+")) {
					throw new Exception("SO LUONG KHACH PHAI LA SO NGUYEN DUONG! ");
				}
				soLuongKhach = Integer.parseInt(input);
				if (soLuongKhach <= 0) {
					throw new Exception("SO LUONG KHACH PHAI LON HON 0");
				}
				break;
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} while (true);

		do {
			try {
				System.out.print("NHAP SO LUONG PHONG: ");
				String input = scanner.nextLine();
				if (!input.matches("\\d+")) {
					throw new Exception("SO LUONG PHONG PHAI LA SO NGUYEN DUONG");
				}
				soLuongPhong = Integer.parseInt(input);
				if (soLuongPhong <= 0) {
					throw new Exception("SO LUONG PHONG PHAI LON HON 0");
				}
				break;
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} while (true);

		// Chuyển đổi chuỗi ngày thành đối tượng Date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date ngayDat = null;
		boolean isValidDate = false;
		while (!isValidDate) {
			try {
				sdf.setLenient(false);
				ngayDat = sdf.parse(ngayDatStr);
				isValidDate = true;
			} catch (ParseException e) {
				System.out.println("NGAY KHONG DUNG DINH DANG yyyy/MM/dd");
				System.out.print("VUI LONG NHAP LAI!: ");
				ngayDatStr = scanner.nextLine();
			}
		}

		// Tạo câu lệnh SQL để kiểm tra trùng lặp và chèn dữ liệu
		String sqlCheckDuplicate = "SELECT COUNT(*) FROM DATPHONG WHERE maDatPhong = ?";
		String sqlInsert = "INSERT INTO DATPHONG(maDatPhong, maKH, ngayDat, soLuongKhach, soLuongPhong) VALUES (?, ?, ?, ?, ?)";

		// Kiểm tra trùng lặp trước khi chèn dữ liệu
		pstmt = conn.prepareStatement(sqlCheckDuplicate);
		pstmt.setString(1, "DP" + maDatPhong);
		ResultSet rs1 = pstmt.executeQuery();
		rs1.next();
		int count1 = rs1.getInt(1);
		if (count1 > 0) {
			System.out.println("MA DAT PHONG NAY DA TON TAI, VUI LONG NHAP LAI!");
			return;
		}

		// Chèn dữ liệu vào bảng DATPHONG
		pstmt = conn.prepareStatement(sqlInsert);
		pstmt.setString(1, "DP" + maDatPhong);
		pstmt.setString(2, "KH" + maKH);
		pstmt.setDate(3, new java.sql.Date(ngayDat.getTime()));
		pstmt.setInt(4, soLuongKhach);
		pstmt.setInt(5, soLuongPhong);

		// Thực hiện truy vấn chèn dữ liệu
		int rows = pstmt.executeUpdate();
		if (rows > 0) {
			System.out.println("DANG KY KHACH HANG DAI DIEN THANH CONG!");
		}
	}

	public void getphongtrong(Connection connection) throws SQLException {

		String sql = "SELECT PHONG.maPhong, LOAIPHONG.tenLoaiPhong, PHONG.trangThai, PHONG.moTa, PHONG.soLuongToiDa, LOAIPHONG.gia "
				+ "FROM PHONG " + "INNER JOIN LOAIPHONG ON PHONG.maLoaiPhong = LOAIPHONG.maLoaiPhong "
				+ "WHERE PHONG.trangThai = 1";

		PreparedStatement statement = connection.prepareStatement(sql);
		ResultSet resultSet = statement.executeQuery();

		while (resultSet.next()) {
			String maPhong = resultSet.getString("maPhong");
			String tenLoaiPhong = resultSet.getString("tenLoaiPhong");
			boolean trangThai = resultSet.getBoolean("trangThai");
			String moTa = resultSet.getString("moTa");
			int soLuongToiDa = resultSet.getInt("soLuongToiDa");
			int gia = resultSet.getInt("gia");

			System.out.println(maPhong + " - " + tenLoaiPhong + " - " + trangThai + " - " + moTa + " - " + soLuongToiDa
					+ " - " + gia);
		}
	}

	public void updateDPhong(Connection connection) throws SQLException {
		String sql = "UPDATE PHONG SET trangThai = 0 WHERE maPhong = ?";
		PreparedStatement stmt = connection.prepareStatement(sql);

		// Nhập mã phòng
		System.out.println("Nhập mã phòng muốn đặt (định dạng P + 3 chữ số):");
		String maPhong = scanner.nextLine();

		// Kiểm tra trạng thái của phòng
		String checkStatusSql = "SELECT trangThai FROM PHONG WHERE maPhong = ?";
		PreparedStatement checkStatusStmt = connection.prepareStatement(checkStatusSql);
		checkStatusStmt.setString(1, maPhong);
		ResultSet rs = checkStatusStmt.executeQuery();
		if (rs.next() && !rs.getBoolean("trangThai")) {
			System.out.println("Phòng hiện tại không có sẵn. Vui lòng chọn phòng khác.");
			updateDPhong(connection);
			return;
		}

		// Thiết lập tham số cho câu lệnh SQL
		stmt.setString(1, maPhong);
		// Thực thi câu lệnh SQL
		if (stmt.executeUpdate() > 0) {
			System.out.println("Đặt phòng thành công!");
		} else {
			System.out.println("Không tìm thấy phòng cần đặt!");
		}
	}

	public void updateTPhong(Connection connection) throws SQLException {
		String sql = "UPDATE PHONG SET trangThai = 1 WHERE maPhong = ?";
		PreparedStatement stmt = connection.prepareStatement(sql);

		// Nhập mã phòng
		System.out.println("Nhập mã phòng cần trả (định dạng P + 3 chữ số):");
		String maPhong = scanner.nextLine();

		// Kiểm tra trạng thái phòng
		boolean trangThai = true;
		String sqlCheck = "SELECT trangThai FROM PHONG WHERE maPhong = ?";
		PreparedStatement stmtCheck = connection.prepareStatement(sqlCheck);
		stmtCheck.setString(1, maPhong);
		ResultSet rs = stmtCheck.executeQuery();
		if (rs.next()) {
			trangThai = rs.getBoolean("trangThai");
		}

		// Yêu cầu nhập lại nếu trạng thái phòng đang là True
		while (trangThai) {
			System.out.println("Phòng này hiện chưa được thuê, vui lòng nhập lại mã phòng:");
			maPhong = scanner.nextLine();
			stmtCheck.setString(1, maPhong);
			rs = stmtCheck.executeQuery();
			if (rs.next()) {
				trangThai = rs.getBoolean("trangThai");
			}
		}

		// Thiết lập tham số cho câu lệnh SQL
		stmt.setString(1, maPhong);
		// Thực thi câu lệnh SQL
		if (stmt.executeUpdate() > 0) {
			System.out.println("Trả phòng thành công!");
		} else {
			System.out.println("Không tìm thấy phòng cần trả!");
		}
	}

	public void setThanhTien(Connection connection) throws SQLException {
		String maPhong;
		String maDatPhong;
		// Yêu cầu nhập maDatPhong gồm DP có định dạng DP+3 chữ số
		while (true) {
			System.out.print("Nhập mã đặt phòng (DPxxx): ");
			maDatPhong = scanner.nextLine();
			if (!maDatPhong.matches("DP\\d{3}")) {
				System.out.println("Mã đặt phòng không hợp lệ, vui lòng nhập lại");
			} else {
				break;
			}
		}
		// Yêu cầu nhập maPhong có định dang P+3 chữ số
		while (true) {
			System.out.print("Nhập mã phòng (Pxxx): ");
			maPhong = scanner.nextLine();
			if (!maPhong.matches("P\\d{3}")) {
				System.out.println("Mã phòng không hợp lệ, vui lòng nhập lại");
			} else {
				break;
			}
		}
		String sql = "UPDATE CHITIETDATPHONG " + "SET thanhTien = DATEDIFF(DAY, ngayCheckIn, ngayCheckOut) * "
				+ "(SELECT gia FROM PHONG P, LOAIPHONG LP WHERE P.maLoaiPhong = LP.maLoaiPhong AND P.maPhong = ?) "
				+ "WHERE maPhong = ? AND maDatPhong = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			pstmt.setString(1, maPhong);
			pstmt.setString(2, maPhong);
			pstmt.setString(3, maDatPhong);
			int rowsUpdated = pstmt.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("Tính giá thành công!");
				sql = "SELECT thanhTien FROM CHITIETDATPHONG WHERE maPhong = ? AND maDatPhong = ?";
				try (PreparedStatement pstmt2 = connection.prepareStatement(sql)) {
					pstmt2.setString(1, maPhong);
					pstmt2.setString(2, maDatPhong);
					ResultSet rs = pstmt2.executeQuery();
					if (rs.next()) {
						System.out.println("Giá của phòng " + maPhong + " là: " + rs.getDouble("thanhTien"));
					} else {
						System.out.println("Không tìm thấy dữ liệu!");
					}
				}
			} else {
				System.out.println("Không cập nhật được dữ liệu!");
			}
			// Tự động đổi trạng thái từ True sang False.
			sql = "UPDATE CHITIETDATPHONG SET trangThai = 'True' WHERE maPhong = ? AND maDatPhong = ?";
			try (PreparedStatement pstmt2 = connection.prepareStatement(sql)) {
				pstmt2.setString(1, maPhong);
				pstmt2.setString(2, maDatPhong);
				pstmt2.executeUpdate();
			}
		}
	}
	// TÍnh tiền theo ngày
	public void sumTienDay(Connection connection) throws SQLException {
		ResultSet rs = null;
		System.out.print("Mời nhập ngày CheckOut (yyyy/mm/dd): ");
		String ngayCheckOut = "";
		boolean validDate = false;
		while (!validDate) {
			ngayCheckOut = scanner.nextLine();
			// Kiểm tra định dạng ngày tháng năm
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
				sdf.setLenient(false);
				sdf.parse(ngayCheckOut);
				validDate = true;
			} catch (ParseException e) {
				System.out.println("Ngày tháng năm không đúng định dạng! Vui lòng nhập lại (yyyy/mm/dd): ");
			}
		}

		// Tính tổng thanhTien theo ngày CheckOut
		String sql = "SELECT SUM(thanhTien) AS tong FROM CHITIETDATPHONG WHERE ngayCheckOut = ? AND trangThai = 'True'";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setString(1, ngayCheckOut);
		rs = pstmt.executeQuery();
		if (rs.next()) {
			int tong = rs.getInt("tong");
			System.out.println("Tổng thành tiền theo ngày CheckOut " + ngayCheckOut + ": " + tong);
		}
	}

	// TINH TONG TIEN THEO THANG
	public void sumTienMonth(Connection connection) throws SQLException {
		// Nhập tháng và năm
		System.out.print("Mời nhập tháng (mm) và năm (yyyy): ");
		String thang = scanner.next();
		String nam = scanner.next();

		// Tính tổng thanhTien theo tháng
		String sql = "SELECT SUM(thanhTien) AS tong FROM CHITIETDATPHONG WHERE YEAR(ngayCheckOut) = ? AND MONTH(ngayCheckOut) = ? AND trangThai = 'True'";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setString(1, nam);
		pstmt.setString(2, thang);
		ResultSet rs = pstmt.executeQuery();
		if (rs.next()) {
			int tong = rs.getInt("tong");
			System.out.println("Tổng thành tiền theo tháng " + thang + "/" + nam + ": " + tong);
		}

	}

}
