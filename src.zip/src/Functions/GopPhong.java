package Functions;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ChiTietDatPhong;
import model.SuDungPhong;
public class GopPhong {

	public void showRoomEmpty(Connection con) throws SQLException {
		String sql = "SELECT maPhong, moTa, soLuongToiDa, gia " + "FROM LOAIPHONG LP, PHONG P "
				+ "WHERE trangThai = 'False' AND LP.maLoaiPhong = P.maLoaiPhong";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			String maPhong = rs.getString("maPhong");
			String moTa = rs.getString("moTa");
			int soLuongToiDa = rs.getInt("soLuongToiDa");
			float gia = rs.getFloat("gia");
			System.out.println(
					"MaPhong: " + maPhong + ", MoTa: " + moTa + ", SoLuongToiDa: " + soLuongToiDa + ", Gia: " + gia);
		}
		ps.close();
		rs.close();

	}
	
	public void showRoomForCount(int count, Connection con) throws SQLException {
		String sql = "SELECT maPhong, moTa, soLuongToiDa, gia FROM LOAIPHONG LP, PHONG P "
				+ "WHERE trangThai = 'False' AND soLuongToiDa >= ? AND LP.maLoaiPhong = P.maLoaiPhong";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, count);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			String maPhong = rs.getString("maPhong");
			String moTa = rs.getString("moTa");
			int soLuongToiDa = rs.getInt("soLuongToiDa");
			float gia = rs.getFloat("gia");
			System.out.println(
					"MaPhong: " + maPhong + "\t" + ", MoTa: " + moTa + "\t" + ", SoLuongToiDa: " + soLuongToiDa + "\t" + ", Gia: " + gia);
		}
		ps.close();
		rs.close();

	}
	
	public int getMaCTLast (Connection con) throws SQLException {
		String sql = "SELECT MAX(maChiTiet) CHITIET FROM CHITIETDATPHONG";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		int maCT = 0;
		if (rs.next()) {
			maCT = rs.getInt("CHITIET");
		}
		rs.close();
		ps.close();
		return maCT;
	}

	public List<String> roomMaDP (String maDatPhong, Connection con) throws SQLException {
		String sql = "SELECT maPhong FROM CHITIETDATPHONG WHERE maDatPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maDatPhong);
		ResultSet rs = ps.executeQuery();
		List<String> list = new ArrayList<String>();
		while (rs.next()) {
			String maPhong = rs.getString("maPhong");
			list.add(maPhong);
		}
		rs.close();
		ps.close();
		return list;
	}

	public List<String> listMaPhongEmpty (int count, Connection con) throws SQLException {
		String sql = "SELECT maPhong FROM LOAIPHONG LP, PHONG P "
				+ "WHERE trangThai = 'False' AND soLuongToiDa >= ? AND LP.maLoaiPhong = P.maLoaiPhong";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, count);
		ResultSet rs = ps.executeQuery();
		List<String> list = new ArrayList<String>();
		while (rs.next()) {
			String maPhong = rs.getString("maPhong");
			list.add(maPhong);
		}
		rs.close();
		ps.close();
		return list;
	}

	public int countKhachGopPhong(List<String> list, Connection con) throws SQLException {
		String query = "SELECT COUNT(maChiTiet) soNguoi FROM SUDUNGPHONG "
				+ "WHERE maChiTiet IN (SELECT maChiTiet FROM CHITIETDATPHONG WHERE maPhong IN (";
		for (int i = 1; i <= list.size(); i++) {
			if (i == list.size()) {
				query += "?))";
			} else {
				query += "?,";
			}
		}
		PreparedStatement ps = con.prepareStatement(query);
		for (int i = 1; i <= list.size(); i++) {
			ps.setString(i, list.get(i - 1));

		}
		ResultSet rs = ps.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("soNguoi");
		}
		ps.close();
		rs.close();
		return count;
	}

	public int countRoomGop (String maDatPhong, Connection con) throws SQLException {
		String sql = "SELECT COUNT(maDatPhong) soPhong FROM CHITIETDATPHONG WHERE maDatPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maDatPhong);
		ResultSet rs = ps.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("soPhong");
		}
		return count;
	}
	
	public void insertCT(ChiTietDatPhong ct, Connection con) throws SQLException {
		String sql = "INSERT INTO CHITIETDATPHONG " + "(maChiTiet, maDatPhong, maPhong, ngayCheckIn, ngayCheckOut) "
				+ "VALUES (?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, ct.getMaChiTiet());
		ps.setString(2, ct.getMaDatPhong());
		ps.setString(3, ct.getMaPhong());
		ps.setDate(4, ct.getNgayCheckIn());
		ps.setDate(5, ct.getNgayCheckOut());
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}

	public void deleteSD(List<String> list, Connection con) throws SQLException {
		String sql = "DELETE FROM SUDUNGPHONG WHERE maChiTiet IN "
				+ "(SELECT maChiTiet FROM CHITIETDATPHONG WHERE maPhong IN (";
		for (int i = 1; i <= list.size(); i++) {
			if (i == list.size()) {
				sql += "?))";
			} else {
				sql += "?,";
			}
		}
		PreparedStatement ps = con.prepareStatement(sql);
		for (int i = 1; i <= list.size(); i++) {
			ps.setString(i, list.get(i - 1));
		}
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}

	public void insertSD(SuDungPhong sd, Connection con) throws SQLException {
		String sql = "INSERT INTO SUDUNGPHONG (maChiTiet, maKH) " + "VALUES (?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, sd.getMaChiTiet());
		ps.setString(2, sd.getMaKH());
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}

	public void deleteCT(List<String> list, Connection con) throws SQLException {
		String sql = "DELETE FROM CHITIETDATPHONG WHERE maPhong IN (";
		for (int i = 1; i <= list.size(); i++) {
			if (i == list.size()) {
				sql += "?)";
			} else {
				sql += "?,";
			}
		}
		PreparedStatement ps = con.prepareStatement(sql);
		for (int i = 1; i <= list.size(); i++) {
			ps.setString(i, list.get(i - 1));
		}
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}
	
	public List<String> getMaKH(List<String> list, Connection con) throws SQLException {
		String sql = "SELECT maKH FROM SUDUNGPHONG "
				+ "WHERE maChiTiet IN (SELECT maChiTiet FROM CHITIETDATPHONG WHERE maPhong IN (";
		for (int i = 1; i <= list.size(); i++) {
			if (i == list.size()) {
				sql += "?))";
			} else {
				sql += "?,";
			}
		}
		PreparedStatement ps = con.prepareStatement(sql);
		for (int i = 1; i <= list.size(); i++) {
			ps.setString(i, list.get(i - 1));
		}
		ResultSet rs = ps.executeQuery();
		List<String> listKH = new ArrayList<String>();
		while (rs.next()) {
			String maKH = rs.getString("maKH");
			listKH.add(maKH);
		}
		ps.close();
		rs.close();
		return listKH;
	}
	
	public List<String> existInSD(int maChiTiet, Connection con) throws SQLException {
		String sql = "SELECT maKH FROM SUDUNGPHONG WHERE maChiTiet = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, maChiTiet);
		List<String> list = new ArrayList<>();
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			String maKH = rs.getString("maKH");
			list.add(maKH);
		}
		rs.close();
		ps.close();
		return list;
	}

	public String getMaDP(String maPhong, Connection con) throws SQLException {
		String sql = "SELECT maDatPhong FROM CHITIETDATPHONG WHERE maPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maPhong);
		ResultSet rs = ps.executeQuery();
		String maDP = null;
		if (rs.next()) {
			maDP = rs.getString("maDatPhong");
		}
		ps.close();
		rs.close();
		return maDP;
	}

	public Date getCheckIn(String maDatPhong, Connection con) throws SQLException {
		String sql = "SELECT ngayCheckIn FROM CHITIETDATPHONG WHERE maDatPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maDatPhong);
		ResultSet rs = ps.executeQuery();
		Date checkIn = null;
		if (rs.next()) {
			checkIn = rs.getDate("ngayCheckIn");
		}
		ps.close();
		rs.close();
		return checkIn;
	}

	public void setThanhTien(String maPhong, int maChitiet, Connection con) throws SQLException {
		String sql = "UPDATE CHITIETDATPHONG SET " + "thanhTien = (SELECT gia FROM PHONG P , CHITIETDATPHONG CT, LOAIPHONG LP "
				+ "WHERE P.maLoaiPhong = LP.maLoaiPhong AND CT.maPhong = P.maPhong AND P.maPhong = ? "
				+ "GROUP BY gia)*"
				+ "(CASE WHEN ngayCheckIn = ngayCheckOut THEN 1 ELSE DATEDIFF(DAY,ngayCheckIn,ngayCheckOut) END)"
				+ "WHERE maChiTiet = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maPhong);
		ps.setInt(2, maChitiet);;
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}

	public void setTruongPhong(String maKH, Connection con) throws SQLException {
		String sql = "UPDATE SUDUNGPHONG SET TruongPhong = 'True' WHERE maKh = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, maKH);
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}
	
	public void setRoomEmpty(String maPhong, Connection con) throws SQLException {
		String sql = "UPDATE PHONG SET trangThai = 'False' WHERE maPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setNString(1, maPhong);
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}
	
	public void setRoomBooked (String maPhong, Connection con) throws SQLException {
		String sql = "UPDATE PHONG SET trangThai = 'True' WHERE maPhong = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setNString(1, maPhong);
		if (ps.executeUpdate() > 0) {
		} else {
		}
		ps.close();
	}

	public void showPhongGop (int maChiTiet, Connection con) throws SQLException {
		String sql = "SELECT maPhong, maKH FROM SUDUNGPHONG SD, CHITIETDATPHONG CT "
				+ "WHERE SD.maChiTiet = ? AND SD.maChiTiet = CT.maChiTiet";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, maChiTiet);
		ResultSet rs = ps.executeQuery();
		String maPhong = null;
		String maKH = null;
		System.out.println("MÃ PHÒNG" + "\t" + "|" + "\t" + "MÃ KHÁCH HÀNG");
		while (rs.next()) {
			maPhong = rs.getString("maPhong");
			maKH = rs.getString("maKH");
			System.out.println(maPhong + "\t" + "|" + "\t" + maKH);
		}
		rs.close();
		ps.close();
	}
}
