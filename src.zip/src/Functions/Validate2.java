package Functions;

import java.lang.reflect.MalformedParameterizedTypeException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import database.JDBCUtil;
import model.ChiTietDatPhong;
import model.DatPhong;
//Khiet
import model.KhachHang;

public class Validate2 {
	// VALIDATE KIEM TRA DIEU KIEN NHAP MA
	// PHONG*****************************************************************
	static Scanner scanner = new Scanner(System.in);


	public static String checkMaP(Scanner sc, String displayScreen) throws SQLException {
		System.out.print(displayScreen);
		String maP = scanner.nextLine();
		while (!maP.matches("^[0-9]{2}$") || check_Trung(maP) == true) {
			System.out.print("Mã phòng đại diện không hợp lệ hoặc bị trùng . Vui lòng nhập lại: ");
			maP = scanner.nextLine();
		}
		return maP;
	}

	public static boolean check_Trung(String maP) throws SQLException {
		Connection conn = JDBCUtil.getConnection();
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				String sql = "Select * From PHONG where maPhong = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, "MP" + maP);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}

			} catch (SQLException e) {

				e.printStackTrace();

			} catch (Exception e) {

				e.printStackTrace();

			} finally {
				conn.close();
			}
		} while (true);
	}

	// KIEM TRA MA PHONG CO TRUNG KO ,KHI NHAP MA PHONG
	// UPDATE********************************
	public static String check_TrungMP(String maP) throws SQLException {
		Connection conn = JDBCUtil.getConnection();
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				String sql = "Select * From PHONG where maPhong = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, "MP" + maP);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					System.out.println("NHAP SAI MA PHONG. MOI NHAP LAI:");
					String mp1 = scanner.nextLine();
					return check_TrungMP(mp1);
				} else {
					conn.close();
					return maP;
				}

			} catch (SQLException e) {

				e.printStackTrace();

			} catch (Exception e) {

				e.printStackTrace();

			} finally {
				conn.close();
			}
		} while (true);
	}

	// VALIDATE KIEM TRA DIEU KIEN NHAP MA LOAI
	// PHONG*****************************************************************
	public static String checkMaLP(Scanner sc, String displayScreen) throws SQLException {
		System.out.print(displayScreen);
		String maLP = scanner.nextLine();
		while (!maLP.matches("^[0-9]{2}$") || check_TrungMLP(maLP) == true) {
			System.out.print("Mã phòng đại diện không hợp lệ hoặc bị trùng . Vui lòng nhập lại: ");
			maLP = scanner.nextLine();
		}
		return maLP;
	}

	public static boolean check_TrungMLP(String maLP) throws SQLException {
		Connection conn = JDBCUtil.getConnection();
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				String sql = "Select * From LOAIPHONG where maloaiPhong = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, "L" + maLP);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
		} while (true);
	}

	// KIEM TRA MA LOAI PHONG CO TRUNG KHONG KHI MUON THEM PHONG MOI, SU DUNG DANH
	// SACH LOAI PHONG
	// CU*************************************************************************
	public static String check_TrungMLP1(String maLP) throws SQLException {
		Connection conn = JDBCUtil.getConnection();
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				String sql = "Select * From LOAIPHONG where maloaiPhong = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, "L" + maLP);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					System.out.println("NHAP SAI MA PHONG . MOI NHAP LAI :");
					String mlp = scanner.nextLine();
					return check_TrungMLP1(mlp);
				} else {
					conn.close();
					return maLP;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
		} while (true);
	}

	// VALIDATE SO LUONG TOI DA//*******************************
	public static int check_SLTD(Scanner sc, String displayScreen) {

		System.out.println("NHAP SO LUONG: ");
		int sl = -1;
		do {
			try {
				sl = Integer.parseInt(scanner.nextLine());
				if (sl > 10 || sl <= 0)
					System.out.println("NHAP SAI. MOI NHAP LAI: ");
			} catch (Exception e) {
				System.out.println("NHAP SAI. MOI NHAP LAI: ");

			}
		} while (sl <= 0 || sl > 10);
		return (sl);
	}
	/*
	 * ublic static void main(String[] args) { int s = check_SLTD(scanner,
	 * "NHAP sl : "); System.out.println(s); }
	 */

/// VALIDATE TRANG THAI PHONG******************
	public static boolean check_TT(Scanner sc, String displayScreen) {
		Boolean boolean1 = false;
		String trangThai = null;
		do {
			System.out.println("NHAP TRUE OR FALSE : ");
			trangThai = scanner.nextLine();
		} while (!trangThai.equalsIgnoreCase("true") && !trangThai.equalsIgnoreCase("false"));
		if (trangThai.equalsIgnoreCase("true")) {
			boolean1 = true;
		} else
			boolean1 = false;
		return boolean1;
	}
	/*
	 * public static void main(String[] args) { boolean s = check_TT(scanner,
	 * "NHAP sl : "); System.out.println(s); }
	 */

//VALIDATE CHECK GIA
	public static double check_Gia(Scanner sc) {
		System.out.println("NHAP GIA PHONG : ");
		double sl = -1;
		do {
			try {
				sl = Double.parseDouble(scanner.nextLine());
				if (sl <= 0)
					System.out.println("NHAP SAI. MOI NHAP LAI: ");
			} catch (Exception e) {
				System.out.println("NHAP SAI. MOI NHAP LAI: ");

			}
		} while (sl <= 0);
		return (sl);
	}
	
	//Validate Hai
	
	public int checkCuPhap(int begin, int end, Scanner scanner) {
        int phim;
        boolean check = false;
        do {
            try {
                if (check)
                	System.out.println("CÚ PHÁP CỦA BẠN KHÔNG ĐÚNG, MỜI NHẬP LẠI:");
                phim = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                phim = 0;
            }
            check = true;
        } while (phim < begin || phim > end);
        return phim;

    }
	
	public String checkMaKH (String displayScreen, Scanner scanner){
		String Validate = "^KH[0-9]{3}$";
		System.out.print(displayScreen);
        String maKH = scanner.nextLine();
        while (!maKH.matches(Validate)) {
        	System.out.println("NHẬP SAI FORMAT (KHxxx), MỜI NHẬP LẠI:");
        	maKH = scanner.nextLine();
        }
        return maKH;
	}
	
	public Boolean existMaKH (String maKH, Connection con) {
		try {
			String sql = "SELECT maKH FROM KHACHHANG";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			KhachHang kh = new KhachHang();
			while (rs.next()) {
				kh = new KhachHang();
				kh.setMaKH(rs.getString("maKH"));
				if (kh.getMaKH().equals(maKH)) {
					return true;
				}
			}
			rs.close();
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
		return false;
	}
	
	public String checkMaDP (String displayScreen, Scanner scanner){
		System.out.print(displayScreen);
		String Validate = "^DP[0-9]{3}$";
        String maDP = scanner.nextLine();
        while (!Validate.matches(maDP)) {
        	System.out.println("NHẬP SAI FORMAT (DPxxx), MỜI NHẬP LẠI:");
        	maDP = scanner.nextLine();
        }
        return maDP;
	}
	
	public Boolean existMaDP (String maDP, Connection con) throws SQLException {
			String sql = "SELECT maDP FROM DATPHONG";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			DatPhong dp = new DatPhong();
			while (rs.next()) {
				dp = new DatPhong();
				dp.setMaKH(rs.getString("maDP"));
				if (dp.getMaDatPhong().equals(maDP)) {
					return true;
				}
			}
			rs.close();
			ps.close();
		return false;
	}
	
	public String checkMaP (String displayScreen, Scanner scanner) {
		System.out.println(displayScreen);
		String Validate = "^P[0-9]{3}$";
		String maPhong = scanner.nextLine();
		while (!maPhong.matches(Validate)) {
			System.out.println("NHẬP SAI FORMAT (Pxxx), MỜI NHẬP LẠI:");
			maPhong = scanner.nextLine();
		}
		return maPhong;
	}
	
	public boolean existMaP (String maP, Connection con) throws SQLException {
		String sql = "SELECT maPhong FROM CHITIETDATPHONG";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		ChiTietDatPhong ct = new ChiTietDatPhong();
		while (rs.next()) {
			ct = new ChiTietDatPhong();
			ct.setMaPhong(rs.getString("maPhong"));
			if (ct.getMaPhong().equals(maP)) {
				return true;
			}
		}
		rs.close();
		ps.close();
		return false;
	}
	

    public String checkNumberPhone(Scanner scanner, String displayScreen) {
        String regexValidateTel = "0[1-9][1-9]{8}";
        System.out.print(displayScreen);
        String input = scanner.nextLine();
        while (!input.matches(regexValidateTel)) {
            System.out.print("Bạn đã nhập sai, mời bạn nhập lại: ");
            input = scanner.nextLine();
        }
        return input;

    }

    public Integer checkInt(String status, int begin, int end, Scanner scanner) {
        int bien;
        try {
            System.out.print(status);
            bien = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            bien = -1;
        }
        while (bien < begin || bien > end) {
            try {
                System.out.println("BẠN ĐÃ QUÁ SỐ, MỜI NHẬP LẠI:");
                bien = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                bien = -1;
            }
        }
        return bien;
    }
  
    public Date checkDate(String message, Scanner scanner) {
		do {
			try {
				System.out.println(message);
				LocalDate date = LocalDate.parse(scanner.nextLine());
				LocalDate minDate = LocalDate.of(1, 1, 1);
				if (date.isBefore(minDate)) {
					System.out.println("KHÔNG ĐƯỢC NHẬP NGÀY ÂM");
				} else if (date.getMonthValue() == 2 && date.lengthOfMonth() > YearMonth.now().lengthOfMonth()) {
					System.out.println("THÁNG 2 CỦA NĂM HIỆN TẠI CHỈ CÓ " + YearMonth.now().lengthOfMonth() + " NGÀY");
				} else {
					return Date.valueOf(date);
				}
			} catch (DateTimeParseException e) {
				System.out.println("VUI LÒNG NHẬP ĐÚNG FORMAT YYYY-MM-DD");
			}
		} while (true);
	}
    



}
