package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtil {
	public static Connection getConnection(){
		String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=QUANLYKHACHSAN;encrypt=true;trustServerCertificate=true";
		String USER_NAME = "sa";
		String PASSWORD = "A9ya8yvahuV6";
		Connection con = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("connect failure!");
			e.printStackTrace();
		}
		return con;
	}
	
	public static void close(Connection con){
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
