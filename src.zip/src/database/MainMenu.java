package database;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Functions.ChuyenPhong;
import Functions.InsertCustomer;
import Functions.QuanLyDatPhongVaThanhToan;
import Functions.QuanLyKhachHang;
import Functions.Validate;
import model.KhachHang;

public class MainMenu {
	private static Validate help = new Validate();
	private static Scanner scanner = new Scanner(System.in);
	private static Connection con = JDBCUtil.getConnection();
	private static SubMenu sub = new SubMenu();
	private static QuanLyDatPhongVaThanhToan ql = new QuanLyDatPhongVaThanhToan();
	public void Phim1() throws SQLException {
		boolean check = true;
		boolean page = true;
		int choicepage;
		int choice;
		while (check) {
			System.out.println("======QUẢN LÝ KHÁCH HÀNG======");
			System.out.println("1.TÌM KIẾM VÀ LỌC THÔNG TIN KHÁCH HÀNG");
			System.out.println("2.THÊM/SỬA/XÓA KHÁCH HÀNG");
			System.out.println("3.QUAY LẠI");
			do {
				try {
					System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
					choice = Integer.parseInt(scanner.nextLine());
				} catch (Exception e) {
					choice = 0;
				}
			} while (choice < 1 || choice > 3);
			System.out.println("================================");
			inner: switch (choice) {
			// 1.1 Tìm kiếm thông tin khách hàng
			case 1:
				while (page) {
					System.out.println("======TÌM KIẾM VÀ LỌC THÔNG TIN KHÁCH HÀNG======");
					System.out.println("1.HIỂN THỊ THÔNG TIN TẤT CẢ KHÁCH HÀNG");
					System.out.println("2.HIỂN THỊ THÔNG TIN KHÁCH HÀNG THEO MÃ KHÁCH");
					System.out.println("3.HIỂN THỊ THÔNG TIN KHÁC HÀNG THEO SĐT");
					System.out.println("4.HIỂN THỊ THÔNG TIN KHÁC HÀNG THEO CCCD");
					System.out.println("5.QUAY LẠI");
					System.out.println("6.QUAY LẠI HỆ THỐNG");
					do {
						try {
							System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
							choicepage = Integer.parseInt(scanner.nextLine());
						} catch (Exception e) {
							choicepage = 0;
						}
					} while (choicepage < 1 || choicepage > 6);
					System.out.println("================================");
					switch (choicepage) {
					// 1.1.1 Hiển thị ALL thông tin khách hàng
					case 1:
						System.out.println("============THÔNG TIN TOÀN BỘ KHÁCH HÀNG ============");
						List<KhachHang> khlist = QuanLyKhachHang.getALL(con);
						for (int i = 0; i < khlist.size(); i++) {
							System.out.println(khlist.get(i).toString());
						}
						System.out.println("====================************====================");
						break;
					// 1.1.2 Tìm thông tin khách hàng bằng mãKH
					case 2:
						System.out.println("============THÔNG TIN KHÁCH HÀNG THEO MÃ KHÁCH HÀNG ============");
						String maKH;
						boolean isMaKHSai;
						do {
							System.out.print("Nhập Mã Khách hàng cần tìm : ");
							maKH = scanner.nextLine();
							if (maKH.matches("KH\\d{3}$")) {
								isMaKHSai = false;
							} else {
								System.out
										.println("Mã khách hàng không hợp lệ, vui lòng nhập lại đúng định dạng KHxxx");
								isMaKHSai = true;
							}
						} while (isMaKHSai);
						System.out.println("====================************====================");
						ArrayList<KhachHang> list = QuanLyKhachHang.getALLmaKH(maKH);
						System.out.println("--------------THÔNG TIN CỦA KHÁCH HÀNG------------");
						for (KhachHang kh : list) {
							System.out.println(kh.toString());
						}
						System.out.println("====================************====================");
						break;
					// 1.1.3 Tim thông tin khách hàng theo SĐT
					case 3:
						System.out.println("============THÔNG TIN KHÁCH HÀNG THEO SĐT KHÁCH HÀNG ============");
						String sdt;
						Boolean isSDTsai;
						do {
							System.out.print("Nhập số điện thoại khách hàng cần tìm: ");
							sdt = scanner.nextLine();
							if (!sdt.matches("^0\\d{9}$")) {
								System.out.println(
										"Số điện thoại không hợp lệ. Vui lòng nhập đúng định dạng (10 chữ số và bắt đầu 0).");
								isSDTsai = true;
							} else {
								isSDTsai = false;
							}
						} while (isSDTsai);
						ArrayList<KhachHang> list1 = QuanLyKhachHang.getALLSDT(sdt);
						System.out.println("--------------THÔNG TIN CỦA KHÁCH HÀNG------------");
						for (KhachHang kh1 : list1) {
							System.out.println(kh1.toString());
						}
						System.out.println("====================************====================");
						break;
					// 1.1.4 Tim thông tin khách hàng theo CCCD
					case 4:
						System.out.println("============THÔNG TIN KHÁCH HÀNG THEO CCCD ============");
						String cccd;
						Boolean isCCCDsai;
						do {
							System.out.print("Nhập CCCD khách hàng cần tìm: ");
							cccd = scanner.nextLine();
							if (!cccd.matches("\\d{12}$")) {
								System.out.println("Số cccd không hợp lệ. Vui lòng nhập đúng định dạng (12 chữ số).");
								isCCCDsai = true;
							} else {
								isCCCDsai = false;
							}
						} while (isCCCDsai);
						ArrayList<KhachHang> list2 = QuanLyKhachHang.getALLCCCD(cccd);
						System.out.println("--------------THÔNG TIN CỦA NHÂN VIÊN------------");
						for (KhachHang kh1 : list2) {
							System.out.println(kh1.toString());
						}
						System.out.println("====================************====================");
						break;
					case 6:
						check = false;
						break inner;
					default:
						page = false;
						break;
					}
				}
				break;
			// Thêm_Sửa_Xoá Thông tin khách hàng
			case 2:
				page = true;
				while (page) {
					System.out.println("======THÊM/SỬA/XÓA KHÁCH HÀNG======");
					System.out.println("1.THÊM MỚI THÔNG TIN KHÁCH HÀNG");
					System.out.println("2.SỬA THÔNG TIN KHÁCH HÀNG THEO MÃ KHÁCH");
					System.out.println("3.XÓA THÔNG TIN KHÁCH HÀNG");
					System.out.println("4.QUAY LẠI");
					System.out.println("5.QUAY LẠI HỆ THỐNG");
					do {
						try {
							System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
							choicepage = Integer.parseInt(scanner.nextLine());
						} catch (Exception e) {
							choicepage = 0;
						}
					} while (choicepage < 1 || choicepage > 4);
					System.out.println("================================");
					switch (choicepage) {
					// Thêm thông tin khách hàng
					case 1:
						KhachHang kh = new KhachHang();
						System.out.print("Nhập vào MaKH : ");
						String maKH = scanner.nextLine();
						boolean checkmaKH;
						do {
							if (maKH.matches("^KH\\d{3}$") && !QuanLyKhachHang.checkExistmaKH(maKH)) {
//								System.out.println("Mã khách hàng đã tồn tại");
								checkmaKH = false;
							} else {
								System.out
										.println("Mã khách hàng đã tồn tại, hoặc định dạng sai(KHxxx), mời nhập lại :");
								maKH = scanner.nextLine();
								checkmaKH = true;
							}
						} while (checkmaKH);
						kh.setMaKH(maKH);
						System.out.print("Nhập vào TenKH :");
						kh.setTenKH(scanner.nextLine());
						System.out.print("Nhập vào SDT : ");
						String sdt = scanner.nextLine();
						Boolean checkSDT;
						do {
							if (sdt.matches("^0\\d{9}$") && !QuanLyKhachHang.checkExistSDT(sdt)) {
//								System.out.println(
//										"Số điện thoại không hợp lệ. Vui lòng nhập đúng định dạng (10 chữ số và bắt đầu 0).");
								checkSDT = false;
							} else {
								System.out.println(
										"Số điện thoại không hợp lệ,Hoặc không tồn tại, vui lòng nhập đúng định dạng (10 chữ số và bắt đầu 0).");
								sdt = scanner.nextLine();
								checkSDT = true;
							}
						} while (checkSDT);
						kh.setSdt(sdt);
						System.out.print("Nhập vào CCCD : ");
						String cccd = scanner.nextLine();
						Boolean checkCCCD;
						do {
							if (cccd.matches("\\d{12}$") && !QuanLyKhachHang.checkExistCCCD(cccd)) {
								checkCCCD = false;
							} else {
								System.out.println("Số CCCD bị trùng, hoặc sai định dạng, hãy nhập lại :");
								cccd = scanner.nextLine();
								checkCCCD = true;
							}
						} while (checkCCCD);
						kh.setCCCD(cccd);
						QuanLyKhachHang.insertKhachHang(kh);
						System.out.println("Thêm thông tin khách hàng thành công.");
						System.out.println("====================************====================");
						break;
					// Sửa thông tin khách hàng
					case 2:
						while (page) {
							System.out.println("======SỬA KHÁCH HÀNG======");
							System.out.println("1.UPDATE toàn bộ thông tin khách hàng.");
							System.out.println("2.UPDATE TÊN KHÁCH HÀNG");
							System.out.println("3.UPDATE SĐT KHÁCH HÀNG");
							System.out.println("4.UPDATE CCCD KHÁCH HÀNG");
							System.out.println("5.QUAY LẠI");
							System.out.println("6.QUAY LẠI HỆ THỐNG");
							System.out.println("====================************====================");
							do {
								try {
									System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
									choicepage = Integer.parseInt(scanner.nextLine());
								} catch (Exception e) {
									choicepage = 0;
								}
							} while (choicepage < 1 || choicepage > 6);
							System.out.println("================================");
							switch (choicepage) {
							// Sửa ALL
							case 1:
								System.out.println("Cập nhập thông tin khách hàng.");
								System.out.print("Nhập maKH cần update lại tên khách hàng : ");
								String maKH1 = scanner.nextLine();
								boolean isMaKHSai;
								do {
									System.out.print("Nhập Mã Khách hàng cần update : ");
									maKH1 = scanner.nextLine();
									if (maKH1.matches("KH\\d{3}$")) {
										isMaKHSai = false;
									} else {
										System.out.println("Mã khách hàng không hợp lệ, vui lòng nhập lại");
										isMaKHSai = true;
									}
								} while (isMaKHSai);
								System.out.print("Tên khách hàng cần update : ");
								String tenKH = scanner.nextLine();
								System.out.print("SĐT cần update : ");
								String sdt1 = scanner.nextLine();
								Boolean isSDTsai;
								do {
									System.out.print("Nhập số điện thoại khách hàng cần update: ");
									sdt1 = scanner.nextLine();
									if (!sdt1.matches("^0\\d{9}$")) {
										System.out.println(
												"Số điện thoại không đúng( bị trùng ), hoặc sai định dạng(10 chữ số và bắt đầu 0), hãy nhập lại : ");
										isSDTsai = true;
									} else {
										isSDTsai = false;
									}
								} while (isSDTsai);
								System.out.print("CCCDcần update : ");
								String cccd1 = scanner.nextLine();
								Boolean isCCCDsai;
								do {
									System.out.print("Nhập CCCD khách hàng cần update: ");
									cccd1 = scanner.nextLine();
									if (!cccd1.matches("\\d{12}$")) {
										System.out.println(
												"Số cccd không hợp lệ. Vui lòng nhập đúng định dạng (12 chữ số) : ");
										isCCCDsai = true;
									} else {
										isCCCDsai = false;
									}
								} while (isCCCDsai);
								QuanLyKhachHang.getUpdateALL(maKH1, tenKH, sdt1, cccd1);
								System.out.println("Cập nhật thông tin thành công.");
								System.out.println("====================************====================");
								break;
							// Sửa tên KH
							case 2:
								System.out.println("Cập nhập thông tin khách hàng.");
								System.out.print("Nhập maKH cần update lại tên khách hàng : ");
								String maKH11 = scanner.nextLine();
								boolean isMaKHSai1;
								do {
									System.out.print("Nhập Mã Khách hàng cần update : ");
									maKH11 = scanner.nextLine();
									if (maKH11.matches("KH\\d{3}$")) {
										isMaKHSai1 = false;
									} else {
										System.out.println("Mã khách hàng không hợp lệ, vui lòng nhập lại");
										isMaKHSai1 = true;
									}
								} while (isMaKHSai1);
								System.out.print("Tên khách hàng cần update : ");
								String tenKH1 = scanner.nextLine();
								QuanLyKhachHang.getUpdateTENKH(maKH11, tenKH1);
								System.out.println("Cập nhật thông tin thành công.");
								System.out.println("====================************====================");
								break;
							// Sửa SĐT
							case 3:
								System.out.println("Cập nhập thông tin khách hàng.");
								System.out.print("Nhập maKH cần update số điện thoại : ");
								String maKH2 = scanner.nextLine();
								boolean isMaKHSai2;
								do {
									System.out.print("Nhập Mã Khách hàng cần update : ");
									maKH11 = scanner.nextLine();
									if (maKH11.matches("KH\\d{3}$")) {
										isMaKHSai2 = false;
									} else {
										System.out.println("Mã khách hàng không hợp lệ, vui lòng nhập lại");
										isMaKHSai2 = true;
									}
								} while (isMaKHSai2);
								System.out.print("Số điện thoại cần update : ");
								String sdt2 = scanner.nextLine();
								Boolean isSDTsai2;
								do {
									System.out.print("Nhập số điện thoại khách hàng cần update: ");
									sdt1 = scanner.nextLine();
									if (!sdt1.matches("^0\\d{9}$")) {
										System.out.println(
												"Số điện thoại không hợp lệ. Vui lòng nhập đúng định dạng (10 chữ số và bắt đầu 0).");
										isSDTsai2 = true;
									} else {
										isSDTsai2 = false;
									}
								} while (isSDTsai2);
								QuanLyKhachHang.getUpdateSDT(maKH2, sdt2);
								System.out.println("Cập nhật thông tin thành công.");
								System.out.println("====================************====================");
								break;
							// Sửa CCCD
							case 4:
								System.out.println("Cập nhập thông tin khách hàng.");
								System.out.print("Nhập maKH cần update CCCD : ");
								String maKH4 = scanner.nextLine();
								boolean isMaKHSai4;
								do {
									System.out.print("Nhập Mã Khách hàng cần update : ");
									maKH11 = scanner.nextLine();
									if (maKH11.matches("KH\\d{3}$")) {
										isMaKHSai4 = false;
									} else {
										System.out.println("Mã khách hàng không hợp lệ, vui lòng nhập lại");
										isMaKHSai4 = true;
									}
								} while (isMaKHSai4);
								System.out.print("Nhập CCCD cần update : ");
								String cccd3 = scanner.nextLine();
								Boolean isCCCDsai3;
								do {
									System.out.print("Nhập CCCD khách hàng cần update: ");
									cccd1 = scanner.nextLine();
									if (!cccd1.matches("\\d{12}$")) {
										System.out.println(
												"Số cccd không hợp lệ. Vui lòng nhập đúng định dạng (12 chữ số).");
										isCCCDsai3 = true;
									} else {
										isCCCDsai3 = false;
									}
								} while (isCCCDsai3);
								QuanLyKhachHang.getUpdateCCCD(maKH4, cccd3);
								System.out.println("Cập nhật thông tin thành công.");
								System.out.println("====================************====================");
								break;
							case 6:
								check = false;
								break inner;
							default:
								page = false;
								break;
							}
						}
					case 3:
						System.out.println("Nhập maKH cần xoá : ");
						String maKH5 = scanner.next();
						boolean isMaKHSai5;
						do {
							System.out.print("Nhập Mã Khách hàng cần update : ");
							maKH5 = scanner.nextLine();
							if (maKH5.matches("KH\\d{3}$")) {
								isMaKHSai5 = false;
							} else {
								System.out.println("Mã khách hàng không hợp lệ, vui lòng nhập lại");
								isMaKHSai5 = true;
							}
						} while (isMaKHSai5);
						QuanLyKhachHang.getdeleteKH(maKH5, con);
						System.out.println("====================************====================");
						break;
					case 5:
						check = false;
						break inner;
					default:
						page = false;
						break;
					}
				}
				break;
			default:
				check = false;
				break;
			}

		}

	
	}

	public void Phim2() throws SQLException {
		boolean check = true;
		boolean page = true;
		int choice;
		while (check) {
			System.out.println("======QUẢN LÝ PHÒNG VÀ LOẠI PHÒNG======");
			System.out.println("1.HIỂN THỊ THÔNG TIN TẤT CẢ PHÒNG");
			System.out.println("2.TÌM KIẾM, SẮP XẾP VÀ LỌC PHÒNG");
			System.out.println("3.THÊM/SỬA/XÓA PHÒNG");
			System.out.println("4.HIỂN THỊ THÔNG TIN TẤT CẢ LOẠI PHÒNG");
			System.out.println("5.TÌM KIẾM, SẮP XẾP VÀ LỌC LOẠI PHÒNG");
			System.out.println("6.THÊM/SỬA/XÓA LOẠI PHÒNG");
			System.out.println("7.QUAY LẠI");
			System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
			choice = help.checkCuPhap(1, 7, scanner);
			System.out.println("====================================");
			inner: switch (choice) {
			case 1:
				sub.showInforPhong();
				break;
			case 2:
				while (page) {
					System.out.println("======TÌM KIẾM, SẮP XẾP VÀ LỌC PHÒNG======");
					System.out.println("1.TÌM KIẾM PHÒNG THEO LOẠI PHÒNG");
					System.out.println("2.TÌM KIẾM PHÒNG THEO GIÁ");
					System.out.println("3.SẮP XẾP PHÒNG THEO GIÁ");
					System.out.println("4.HIỂN THỊ PHÒNG CÒN TRỐNG");
					System.out.println("5.HIỂN THỊ PHÒNG ĐÃ ĐẶT");
					System.out.println("6.QUAY LAI");
					System.out.println("7.QUAY LAI HỆ THỐNG");
					System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
					int choicepage = help.checkCuPhap(1, 7, scanner);
					System.out.println("====================================");
					switch (choicepage) {
					case 1:
						sub.searchP_tenLoaiPhong();
						break;
					case 2:
						sub.searchP_Gia();
						break;
					case 3:
						sub.sapxepPhong_Gia();
						break;
					case 4:
						sub.showInforPhong_Trong();
						break;
					case 5:
						sub.showInforPhong_DADAT();
						break;
					case 7:
						check = false;
						break inner;
					default:
						page = false;
						break;
					}
				}
				break;
			case 3:
				while (page) {
					System.out.println("======THÊM/SỬA/XÓA PHÒNG======");
					System.out.println("1.THÊM PHÒNG");
					System.out.println("2.SỬA THÔNG TIN PHÒNG");
					System.out.println("3.XÓA PHÒNG");
					System.out.println("4.QUAY LẠI");
					System.out.println("5.QUAY LAI HỆ THỐNG");
					System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
					int choicepage = help.checkCuPhap(1, 5, scanner);
					System.out.println("====================================");
					switch (choicepage) {
					case 1:
						sub.themPhong();
						break;
					case 2:
						sub.updatePhong_maPhong();
						break;
					case 3:
						sub.deletePhong_mp();
						break;
					case 5:
						check = false;
						break inner;
					default:
						page = false;
						break;
					}
				}
				break;
			case 4:
				sub.showInforloaiPhong();
				break;
			case 5:
				while (page) {
					System.out.println("======TÌM KIẾM, SẮP XẾP VÀ LỌC LOẠI PHÒNG======");
					System.out.println("1.SẮP XẾP LOẠI PHÒNG THEO GIÁ GIẢM DẦN");
					System.out.println("2.SẮP XẾP LOẠI PHÒNG THEO GIÁ TĂNG DẦN ");
					System.out.println("3.QUAY LẠI");
					System.out.println("4.QUAY LAI HỆ THỐNG");
					System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
					int choicepage = help.checkCuPhap(1, 4, scanner);
					System.out.println("====================================");
					switch (choicepage) {
					case 1:
						sub.sapxepLoaiPhong_giaGIAM();
						break;
					case 2:
						sub.sapxepLoaiPhong_giaTang();
						break;
					case 4:
						check = false;
						break inner;
					default:
						page = false;
						break;
					}
				}
				break;
			case 6:
				while (page) {
					System.out.println("======THÊM/SỬA/XÓA LOẠI PHÒNG======");
					System.out.println("1.THÊM LOẠI PHÒNG");
					System.out.println("2.SỬA THÔNG TIN LOẠI PHÒNG");
					System.out.println("3.XÓA LOẠI PHÒNG");
					System.out.println("4.QUAY LẠI");
					System.out.println("5.QUAY LAI HỆ THỐNG");
					System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
					int choicepage = help.checkCuPhap(1, 4, scanner);
					System.out.println("====================================");
					switch (choicepage) {
					case 1:
						sub.themloaiPhong();
						break;
					case 2:
						sub.updateLoaiPhong_maLoaiPhong();
						break;
					case 3:
						sub.deleteLoaiPhong_mlp();
						break;
					case 5:
						check = false;
						break inner;
					default:
						page = false;
						break;
					}
				}
				break;
			default:
				check = false;
				break;
			}
		}
	}

	public void Phim3() throws SQLException {
		boolean page = true;
		InsertCustomer ic = new InsertCustomer();
		while (page) {
			System.out.println("======QUẢN LÝ ĐẶT PHÒNG VÀ THANH TOÁN======");
			System.out.println("1.ĐẶT PHÒNG");
			System.out.println("2.THÊM THÔNG TIN KHÁCH HÀNG ĐẠI DIỆN");
			System.out.println("3.KIỂM TRA PHÒNG CÒN TRỐNG");
			System.out.println("4.CHỌN PHÒNG");
			System.out.println("5.TRẢ PHÒNG");
			System.out.println("6.TÍNH TIỀN PHÒNG");
			System.out.println("7.QUAY LẠI");
			System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
			int choice = help.checkCuPhap(1, 7, scanner);
			System.out.println("====================================");
			switch (choice) {
			case 1:
				ic.insertCustomer(con);
				break;
			case 2:
				ql.addmaKH(con);
				break;
			case 3:
				ql.getphongtrong(con);
				break;
			case 4:
				ql.updateDPhong(con);
				break;
			case 5:
				ql.updateTPhong(con);
				break;
			case 6:
				ql.setThanhTien(con);
				break;
			default:
				page = false;
				break;
			}
		}
	}

	public void Phim4() throws SQLException {
		ChuyenPhong chuyenPhong = new ChuyenPhong();
		boolean page = true;
			while (page) {
				System.out.println("======YÊU CẦU KHÁCH HÀNG======");
				System.out.println("1.KHÁCH CHUYỂN PHÒNG");
				System.out.println("2.KHÁCH GỘP PHÒNG");
				System.out.println("3.KHÁCH TÁCH PHÒNG");
				System.out.println("4.QUAY LẠI");
				System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
				int choice = help.checkCuPhap(1, 4, scanner);
				System.out.println("====================================");
				switch (choice) {
				case 1:
					chuyenPhong.chuyenPhong();
					break;
				case 2:
					sub.gopPhong();
					break;
				case 3:
					sub.tachPhong();
					break;
				default:
					page = false;
					break;
				}
			}
		
	}

	public void Phim5() throws SQLException {
		boolean page = true;
		while (page) {
			System.out.println("===================================="); 	
			System.out.println("1.DOANH THU THEO NGAY");
			System.out.println("2.DOANH THU THEO THÁNG");
			System.out.println("3.QUAY LẠI");
			System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
			int choice = help.checkCuPhap(1, 3, scanner);
			System.out.println("====================================");
			switch (choice) {
			case 1:
				ql.sumTienDay(con);
				break;
			case 2:
				ql.sumTienMonth(con);
				break;
			default:
				page = false;
				break;
			}
		}
	}

}
