package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.microsoft.sqlserver.jdbc.SQLServerException;

import Functions.GopPhong;
import Functions.TachPhong;
import Functions.Validate;
import Functions.Validate2;
import model.ChiTietDatPhong;
import model.SuDungPhong;

public class SubMenu {
	private static Connection con = JDBCUtil.getConnection();
	private static Scanner scanner = new Scanner(System.in);
	private static Validate help = new Validate();
	private static Validate2 validate = new Validate2();

	/**
	 * Mô tả chi tiết gộp phòng: - Nhập mã đặt phòng - nhập số lượng phòng muốn
	 * gộp ==> tạo biến số lượng - nhập những phòng muốn gộp - đếm tổng số người
	 * của các phòng muốn gộp - chọn phòng muốn đổi - INSERT một mã chi tiết mới
	 * với mã phòng gộp trong chitietdatphong - XÓA record theo machitiet cũ
	 * trong sudungphong - INSERT machitiet mới của phòng gộp vào sudungphong -
	 * XÓA record theo maphong cũ muốn gộp trong CHITIETDATPHONG
	 */
	public void gopPhong() throws SQLException, SQLServerException {
		GopPhong gop = new GopPhong();
		ChiTietDatPhong ct = new ChiTietDatPhong();
		SuDungPhong sd = new SuDungPhong();
		String maDP;
		do {
			maDP = help.checkMaDP("NHẬP MÃ ĐẶT PHÒNG: ", scanner);
		} while (!help.existMaDP(maDP, con)); // KIỂM TRA MÃ ĐẶT PHÒNG CÓ TỒN
												// LẠI TRONG BẢNG
												// CHITIETDATPHONG HAY KHÔNG
		List<String> listDP = gop.roomMaDP(maDP, con); // TẠO LIST CHỨA
														// maDatPhong TRONG
														// CHITIETDATPHONG
		int soPhong = gop.countRoomGop(maDP, con); // TẠO BIẾN ĐẾM SỐ PHÒNG THEO
													// maDatPhong
		System.out.println("====================================");
		System.out.println("DANH SÁCH PHÒNG TRONG TOUR:");
		for (String dp : listDP) {
			System.out.print(dp + "\t"); // IN DANH SÁCH PHÒNG THEO maDatPhong
		}
		System.out.println();
		System.out.println("====================================");
		int maChiTiet = gop.getMaCTLast(con); // LẤY maChiTiet CUỐI CÙNG (VÌ
												// maChiTiet TĂNG DẦN)
		int slPhong = help.checkInt("NHẬP SỐ LƯỢNG PHÒNG MUỐN GỘP: ", 2, soPhong, scanner);
		List<String> listMaPhong = new ArrayList<String>(); // TẠO LIST CHỨA MÃ
															// PHÒNG CŨ ĐỂ GỘP
		String maPhong;
		for (int i = 1; i <= slPhong; i++) {
			do {
				maPhong = help.checkMaP("NHẬP MÃ PHÒNG THỨ " + i, scanner);
				if (!listDP.contains(maPhong)) {
					System.out.println("NHẬP SAI MÃ PHÒNG");
				}
			} while (!listDP.contains(maPhong));
			listMaPhong.add(maPhong);
		}
		// TẠO BIẾN CHỨA CÁC maKH TRONG LIST PHÒNG CŨ ĐẾM SỐ LƯỢNG KHÁCH
		List<String> listKH = gop.getMaKH(listMaPhong, con);
		int count = gop.countKhachGopPhong(listMaPhong, con);
		System.out.println("====================================");
		System.out.println("DANH SÁCH CÁC PHÒNG THEO SỐ LƯỢNG KHÁCH MUỐN GỘP: ");
		gop.showRoomForCount(count, con);
		System.out.println("====================================");
		maChiTiet++; // TĂNG maChiTiet ĐỂ TẠO THÀNH 1 PHÒNG MỚI
		ct.setMaChiTiet(maChiTiet);
		// TẠO LIST PHÒNG ĐANG TRỐNG
		List<String> listPhongEmpty = gop.listMaPhongEmpty(count, con);
		String newroom;
		boolean check = true;
		do {
			newroom = help.checkMaP("MỜI CHỌN PHÒNG MUỐN GỘP: ", scanner);
			for (int i = 0; i < listPhongEmpty.size(); i++) {
				if (newroom.equals(listPhongEmpty.get(i))) {
					check = false;
					break;
				}
				System.out.println("MỜI NHẬP ĐÚNG PHÒNG TRONG DANH SÁCH: ");
			}
		} while (check);
		maPhong = listMaPhong.get(0);
		maDP = gop.getMaDP(maPhong, con); // LẤY maDatPhong
		Date checkIn = gop.getCheckIn(maDP, con);
		ct.setMaDatPhong(maDP);
		ct.setMaPhong(newroom);
		ct.setNgayCheckIn(checkIn);
		Date checkOut;
		do {
			checkOut = help.checkDate("NHẬP NGÀY CHECK OUT MỚI (YYYY-MM-DD): ", scanner);
			if (checkOut.compareTo(checkIn) < 0) {
				System.out.println("NGÀY CHECK OUT PHẢI LỚN HƠN NGÀY CHECK IN, MỜI NHẬP LẠI");
			}
		} while (checkOut.compareTo(checkIn) < 0);
		ct.setNgayCheckOut(checkOut);
		gop.insertCT(ct, con); // INSERT RECORD MỚI VÀO CHITIETDATPHONG
		// UPDATE THANHTIEN THEO maPhong và maChiTiet TRONG CHITIETDATPHONG
		gop.setThanhTien(newroom, maChiTiet, con);
		// XÓA RECORD CỦA PHÒNG CŨ TRONG SUDUNGPHONG
		gop.deleteSD(listMaPhong, con);
		for (int i = 0; i < count; i++) { // INSERT RECORD MỚI VÀO SỬ DỤNG PHÒNG
			sd.setMaChiTiet(maChiTiet);
			sd.setMaKH(listKH.get(i));
			gop.insertSD(sd, con);
		}
		gop.deleteCT(listMaPhong, con); // XÓA RECORD CŨ TRONG CHITIETDATPHONG
		// CHUYỂN TRANGTHAI PHÒNG TRỐNG TRONG BẢNG PHONG
		for (int i = 0; i < listMaPhong.size(); i++) {
			gop.setRoomEmpty(listMaPhong.get(i), con);
		}
		// CHUYỂN TRANGTHAI PHÒNG ĐÃ ĐẶT TRONG BẢNG PHÒNG
		gop.setRoomBooked(newroom, con);
		// TẠO LIST maKH TRONG PHÒNG MỚI ĐỂ BẦU TRƯỞNG PHÒNG
		List<String> listInRoom = gop.existInSD(maChiTiet, con);
		String maKH = null;
		check = true;
		do {
			maKH = help.checkMaKH("NHẬP MÃ KHÁCH LÀM TRƯỞNG PHÒNG: ", scanner);
			if (listInRoom.contains(maKH)) {
				check = false;
			} else {
				System.out.println("KHÔNG CÓ MÃ KHÁCH NÀO TRONG PHÒNG, NHẬP LẠI: ");
			}
		} while (check);
		gop.setTruongPhong(maKH, con); // SET TRƯỞNG PHÒNG
		System.out.println("BẠN ĐÃ GỘP PHÒNG THÀNH CÔNG ");
		System.out.println("====================================");
		System.out.println("DANH SÁCH KHÁCH TRONG PHÒNG ĐÃ GỘP: ");
		gop.showPhongGop(maChiTiet, con);
		System.out.println("====================================");
		int out;
		do {
			try {
				System.out.println("NHẬP 1 ĐỂ QUAY LẠI: ");
				out = Integer.parseInt(scanner.nextLine());
			} catch (NumberFormatException e) {
				out = 0;
			}
		} while (out != 1);
	}

	/**
	 * Mô tả tách phòng:
	 *
	 */
	public void tachPhong() throws SQLException, SQLServerException {
		GopPhong gop = new GopPhong();
		TachPhong tach = new TachPhong();
		ChiTietDatPhong ct = new ChiTietDatPhong();
		SuDungPhong sd = new SuDungPhong();
		String roomTach;
		int khachInRoom = 0;
		inner: do {
			roomTach = help.checkMaP("NHẬP MÃ PHÒNG MUỐN TÁCH: ", scanner);
			if (!tach.checkPhong(roomTach, con)) {
				break inner;
			}
			// ĐẾM SỐ LƯỢNG KHÁCH TRONG PHÒNG
			khachInRoom = tach.countTachPhong(roomTach, con);
			if (khachInRoom >= 2) {
				break;
			} else {
				System.out.println("PHÒNG CHỈ CÓ 1 KHÁCH, XIN NHẬP LẠI: ");
			}
		} while (true);
		int maChiTiet = tach.maChiTietTach(roomTach, con);
		// LẤY maChiTiet CŨ ĐỂ CÒN THAO TÁC NHỮNG RECORD CŨ SAU KHI TÁCH PHÒNG
		int maCT = maChiTiet;
		String maDP = gop.getMaDP(roomTach, con);
		System.out.println("====================================");
		System.out.println("DANH SÁCH KHÁCH Ở TRONG PHÒNG: ");
		List<String> listKH = tach.getMaKH(maChiTiet, con);
		for (int i = 0; i < listKH.size(); i++) {
			System.out.print(listKH.get(i) + " ");
		}
		System.out.println();
		System.out.println("=================================================");
		int sumKhach = help.checkInt("NHẬP SỐ LƯỢNG KHÁCH MUỐN TÁCH: ", 1, khachInRoom, scanner);
		int sumPhong = help.checkInt("NHẬP SỐ LƯỢNG PHÒNG MUỐN TÁCH: ", 1, khachInRoom, scanner);
		int cusNum = 1; // TẠO BIẾN ĐẾM SỐ LƯỢNG KHÁCH CỦA TỪNG PHÒNG TÁCH
		for (int i = 1; i <= sumPhong; i++) {
			if (sumKhach > 1 && sumPhong > 1) {
				cusNum = help.checkInt("SỐ NGƯỜI CỦA PHÒNG THỨ " + i, 0, sumKhach, scanner);
				sumKhach -= cusNum;
			}
			// TẠO LIST maKH CỦA PHÒNG MỚI TÁCH
			List<String> listMaKH = new ArrayList<String>();
			String maKH = null;
			for (int j = 1; j <= cusNum; j++) {
				if (cusNum > 1) {
					maKH = help.checkMaKH("NHẬP MÃ KHÁCH HÀNG THỨ " + j + ":", scanner);
				} else {
					maKH = help.checkMaKH("NHẬP MÃ KHÁCH HÀNG: ", scanner);
				}
				listMaKH.add(maKH);
			}
			System.out.println("DANH SÁCH PHÒNG CÒN TRỐNG: ");
			gop.showRoomForCount(cusNum, con);
			// TẠO LIST CHỨA maPhong CÒN TRỐNG
			List<String> roomCusNum = tach.RoomForCount(cusNum, con);
			String maPhong;
			do {
				maPhong = help.checkMaP("MỜI NHẬP MÃ PHÒNG CHỌN: ", scanner);
				if (!roomCusNum.contains(maPhong)) {
					System.out.println("MÃ PHÒNG KHÔNG TỒN TẠI HOẶC ĐÃ ĐƯỢC ĐẶT, MỜI NHẬP LẠI");
				}
			} while (!roomCusNum.contains(maPhong));
			maChiTiet = gop.getMaCTLast(con); // LẤY maChiTiet LỚN NHẤT
			maChiTiet++;
			Date checkIn = tach.getCheckIn(maDP, con); // LẤY ngayCheckIn CŨ
			Date checkOut;
			do {
				checkOut = help.checkDate("NHẬP NGÀY CHECK OUT MỚI (YYYY-MM-DD): ", scanner);
				if (checkOut.compareTo(checkIn) < 0) {
					System.out.println("NGÀY CHECK OUT PHẢI LỚN HƠN NGÀY CHECK IN, MỜI NHẬP LẠI");
				}
			} while (checkOut.compareTo(checkIn) < 0);
			// INSERT RECORD MỚI TRONG CHITIETDATPHONG
			ct.setMaChiTiet(maChiTiet);
			ct.setMaDatPhong(maDP);
			ct.setMaPhong(maPhong);
			ct.setNgayCheckIn(checkIn);
			ct.setNgayCheckOut(checkOut);
			gop.insertCT(ct, con);
			// SET thanhTien CHO RECORD MỚI
			gop.setThanhTien(maPhong, maChiTiet, con);
			// XÓA RECORD CŨ VÀ INSERT RECORD MỚI TRONG SUDUNGPHONG THEO maKH
			for (int a = 0; a < listMaKH.size(); a++) {
				tach.deleteSD(listMaKH.get(a), con);
				sd.setMaChiTiet(maChiTiet);
				sd.setMaKH(listMaKH.get(a));
				gop.insertSD(sd, con);

			}
			boolean check = true;
			List<String> listInRoom = gop.existInSD(maChiTiet, con);
			if (listMaKH.size() > 1) {
				do {
					maKH = help.checkMaKH("NHẬP MÃ KHÁCH LÀM TRƯỞNG PHÒNG: ", scanner);
					if (listInRoom.contains(maKH)) {
						check = false;
					} else {
						System.out.println("KHÔNG CÓ MÃ KHÁCH NÀO TRONG PHÒNG, NHẬP LẠI: ");
					}
				} while (check);
			}
			gop.setTruongPhong(maKH, con);
			// THAY ĐỔI trangThai SANG ĐÃ ĐẶT TRONG BẢNG PHONG
			gop.setRoomBooked(maPhong, con);
		}
		// NẾU TÁCH HẾT TẤT CẢ KHÁCH KHÔNG CÒN Ở PHÒNG CŨ THÌ XÓA RECORD Ở
		// CHITIETDATPHONG
		if (tach.countMaCT(maCT, con) == 0) {
			tach.deleteCT(maCT, con);
		}
		System.out.println("ĐÃ TÁCH THÀNH CÔNG");
		System.out.println("DANH SÁCH CÁC PHÒNG ĐÃ TÁCH:");
		tach.showPhongTach(maDP, con);
		int out;
		do {
			try {
				System.out.println("NHẬP 1 ĐỂ QUAY LẠI: ");
				out = Integer.parseInt(scanner.nextLine());
			} catch (Exception e) {
				out = 0;
			}
		} while (!(out == 1));
	}

	// HIEN THI DANH SACH TAT CA CAC PHONG***************
	public void showInforPhong() {
			System.out.println("MA PHONG" + "\t" + "MA LOAI PHONG" + "\t" + "TRANG THAI" + "\t" + "MO TA" + "\t" + "\t"
					+ "SO LUONG KHACH TOI DA");
			String sql2 = "Select*from Phong";
			try {
				PreparedStatement pr2 = con.prepareStatement(sql2);
				ResultSet rs = pr2.executeQuery();
				while (rs.next()) {
					String mp = rs.getString("maPhong");
					String mlp = rs.getString("maLoaiPhong");
					Boolean tt = rs.getBoolean("trangThai");
					String mt = rs.getString("moTa");
					int sl = rs.getInt("soLuongToiDa");
					System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + tt + "\t" + "\t" + mt + "\t" + "\t" + sl);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	
	// Tìm kiếm và hiển thị phòng theo tenLoaiPhong
	public void searchP_tenLoaiPhong() {
		System.out.println("NHAP TEN LOAI PHONG CAN TIM : ");
		String lp = scanner.nextLine();
		String sql5 = "select p.maPhong,lp.tenLoaiPhong,p.trangThai,lp.gia,p.moTa from PHONG p,LOAIPHONG lp where lp.maLoaiPhong=p.maLoaiPhong and tenLoaiPhong like ?";
		try {
			PreparedStatement pr5 = con.prepareStatement(sql5);
			pr5.setString(1, "%" + lp + "%");
			ResultSet rs5 = pr5.executeQuery();
			System.out.println("MA PHONG" + "\t" + "TEN LOAI PHONG" + "\t" + "TRANG THAI" + "\t" + "GIA PHONG" + "\t"
					+ "\t" + "MO TA");
			while (rs5.next()) {
				String mp = rs5.getString("maPhong");
				String tlp = rs5.getString("tenLoaiPhong");
				Boolean tt = rs5.getBoolean("trangThai");
				String mt = rs5.getString("moTa");
				double gia = rs5.getInt("gia");
				System.out.println(mp + "\t" + "\t" + tlp + "\t" + "\t" + tt + "\t" + "\t" + gia + "\t" + "\t" + mt);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	// Tìm kiếm và hiển thị phòng theo giá
	public void searchP_Gia() {
		double g = Validate2.check_Gia(scanner);
		String sql6 = "select p.maPhong,lp.maLoaiPhong,lp.tenLoaiPhong,p.trangThai,p.moTa from PHONG p,LOAIPHONG lp where lp.maLoaiPhong=p.maLoaiPhong and gia=?";
		try {
			PreparedStatement pr6 = con.prepareStatement(sql6);
			pr6.setDouble(1, g);
			ResultSet rs6 = pr6.executeQuery();
			System.out.println("MA PHONG" + "\t" + "MA LOAI PHONG" + "\t" + "TEN LOAI PHONG" + "\t" + "\t"
					+ "TRANG THAI" + "\t" + "MO TA");
			while (rs6.next()) {
				String mp = rs6.getString("maPhong");
				String mlp = rs6.getString("maLoaiPhong");
				String tlp = rs6.getString("tenLoaiPhong");
				Boolean tt = rs6.getBoolean("trangThai");
				String mt = rs6.getString("moTa");
				System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + tlp + "\t" + "\t" + tt + "\t" + "\t" + mt);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	// Hiển thị và sắp xếp phòng theo giá
	public void sapxepPhong_Gia() {
		System.out.println("MAPHONG" + "\t" + "\t" + "MA LOAI PHONG" + "\t" + "TRANG THAI" + "\t" + "MOTA" + "\t"
				+ "SO LUONG KHACH TOI DA" + "\t" + "GIA PHONG");
		String sql9 = "select p.maPhong,p.maLoaiPhong,p.trangThai,p.moTa,p.soLuongToiDa,lp.gia from PHONG p,LOAIPHONG lp where lp.maLoaiPhong=p.maLoaiPhong  ORDER BY gia";
		try {
			PreparedStatement pr9 = con.prepareStatement(sql9);
			ResultSet rs9 = pr9.executeQuery();
			while (rs9.next()) {
				String mp = rs9.getString("maPhong");
				String mlp = rs9.getString("maLoaiPhong");
				Boolean tt = rs9.getBoolean("trangThai");
				String mt = rs9.getString("moTa");
				int sl = rs9.getInt("soLuongToiDa");
				Double g = rs9.getDouble("gia");
				System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + tt + "\t" + "\t" + mt + "\t" + "\t" + sl
						+ "\t" + "\t" + g);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Hiển thị phòng trống
	public void showInforPhong_Trong() {
		System.out.println("MA PHONG" + "\t" + "MA LOAI PHONG" + "\t" + "TRANG THAI" + "\t" + "MO TA" + "\t" + "\t"
				+ "SO LUONG KHACH TOI DA");
		String sql7 = "Select maPhong,maLoaiPhong,trangThai,moTa,soLuongToiDa from Phong Where trangThai='True'";
		try {
			PreparedStatement pr7 = con.prepareStatement(sql7);
			ResultSet rs7 = pr7.executeQuery();
			while (rs7.next()) {
				String mp = rs7.getString("maPhong");
				String mlp = rs7.getString("maLoaiPhong");
				Boolean tt = rs7.getBoolean("trangThai");
				String mt = rs7.getString("moTa");
				int sl = rs7.getInt("soLuongToiDa");
				System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + tt + "\t" + "\t" + mt + "\t" + "\t" + sl);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Hiển thị phòng đã đặt
	public void showInforPhong_DADAT() {
		System.out.println("MA PHONG" + "\t" + "MA LOAI PHONG" + "\t" + "TRANG THAI" + "\t" + "MO TA" + "\t" + "\t"
				+ "SO LUONG KHACH TOI DA");

		String sql8 = "Select maPhong,maLoaiPhong,trangThai,moTa,soLuongToiDa from Phong Where trangThai='False'";
		try {
			PreparedStatement pr8 = con.prepareStatement(sql8);
			ResultSet rs8 = pr8.executeQuery();
			while (rs8.next()) {
				String mp = rs8.getString("maPhong");
				String mlp = rs8.getString("maLoaiPhong");
				Boolean tt = rs8.getBoolean("trangThai");
				String mt = rs8.getString("moTa");
				int sl = rs8.getInt("soLuongToiDa");
				System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + tt + "\t" + "\t" + mt + "\t" + "\t" + sl);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Thêm phòng
	public void themPhong() {
		String sql1 = "insert into PHONG(maPhong,maLoaiPhong,trangThai,moTa,soLuongToiDa)" + "values(?,?,?,?,?)";
		PreparedStatement pr = null;
		try {
			pr = con.prepareStatement(sql1);
			String maP = validate.checkMaP("NHAP MA PHONG : ", scanner);
			pr.setString(1, "MP" + maP);
			System.out.println("BAN CO MUON SU DUNG MA LOAI PHONG CU KHONG ");
			System.out.println("1.CO ");
			System.out.println("2.KHONG ");
			Scanner scanner = new Scanner(System.in);
			int choice = Integer.parseInt(scanner.nextLine());
			switch (choice) {
			case 1:
				break;
			case 2:
				themloaiPhong();
				break;
			default:
				System.out.println("Moi nhap lai su lua chon : ");
			}
			System.out.println("NHAP MA LOAI PHONG : ");
			String mlp = scanner.nextLine();
			Validate2.check_TrungMLP1(mlp);
			pr.setString(2, "L" + mlp);
			Boolean tt = true;
			pr.setBoolean(3, tt);
			System.out.println("NHAP MO TA PHONG : ");
			String mt = scanner.nextLine();
			pr.setString(4, mt);
			int sl = Validate2.check_SLTD(scanner, "NHAP SO LUONG KHACH TOI DA : ");
			pr.setInt(5, sl);
			int check = pr.executeUpdate();
			if (check != 0) {
				System.out.println("INTSERT PHONG MOI THANH CONG");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// UPDATE PHONG THEO MA PHONG*************
	public void updatePhong_maPhong() throws SQLException {
		System.out.println("NHAP MA PHONG CAN UPDATE: ");
		String updateMP = scanner.nextLine();
		updateMP = Validate2.check_TrungMP(updateMP);
		// System.out.println(updateMP);
		String sql3 = "update PHONG set maLoaiPhong=?,trangThai=?,moTa=?,soLuongToiDa=? where maPhong=?";
		try {
			PreparedStatement pr3 = con.prepareStatement(sql3);
			System.out.println("BAN CO MUON SU DUNG MA LOAI PHONG CU KHONG ");
			System.out.println("1.CO ");
			System.out.println("2.KHONG ");
			Scanner scanner = new Scanner(System.in);
			int choice = Integer.parseInt(scanner.nextLine());
			switch (choice) {
			case 1:
				break;
			case 2:
				themloaiPhong();
				break;
			default:
				System.out.println("Moi nhap lai su lua chon : ");
			}
			System.out.println("NHAP MA LOAI PHONG : ");
			String mlp = scanner.nextLine();
			mlp = Validate2.check_TrungMLP1(mlp);
			// System.out.println(mlp);
			pr3.setString(1, "L" + mlp);
			boolean tt = Validate2.check_TT(scanner, "TRANG THAI: ");
			pr3.setBoolean(2, tt);
			System.out.println("NHAP MO TA PHONG : ");
			String mt = scanner.nextLine();
			pr3.setString(3, mt);
			int sl = Validate2.check_SLTD(scanner, "NHAP SO LUONG KHACH TOI DA : ");
			pr3.setInt(4, sl);
			pr3.setString(5, "MP" + updateMP);
			int rowUpdate = pr3.executeUpdate();
			if (rowUpdate != 0)
				System.out.println("update thanh cong");
			else {
				System.out.println("khong tim thay ma phong can update");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// XOA PHONG THEO MA PHONG***********
	public void deletePhong_mp() {
			System.out.println("NHAP MA PHONG CAN XOA : ");
			String deleteMP = scanner.nextLine();
			String sql4 = "Delete from Phong where maPhong=?";
			try {
				PreparedStatement pr4 = con.prepareStatement(sql4);
				pr4.setString(1,"MP"+ deleteMP);
				int rowDeleted = pr4.executeUpdate();
				if (rowDeleted != 0)
					System.out.println("Da xoa thanh cong ma phong " + deleteMP);
				else
					System.out.println("Khong tim thay ma phong  can xoa");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	// HIEN THI THONG TIN TAT CA CAC LOAI PHONG***************
	public void showInforloaiPhong() {
			String sql10 = "Select*from LOAIPHONG";
			try {
				PreparedStatement pr2 = con.prepareStatement(sql10);
				ResultSet rs10 = pr2.executeQuery();
				System.out.println("MA LOAI PHONG" + "\t" + "TEN LOAI PHONG" + "\t" + "\t" + "GIA");
				while (rs10.next()) {
					String mp = rs10.getString("maLoaiPhong");
					String mlp = rs10.getString("tenLoaiPhong");
					Double g = rs10.getDouble("gia");
					System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + g);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	// SAP XEP LOAI PHONG THEO GIA GIAM DAN***************
	public void sapxepLoaiPhong_giaGIAM() {
		String sql12 = "select * from LOAIPHONG ORDER BY gia DESC";
		try {
			PreparedStatement pr12 = con.prepareStatement(sql12);
			ResultSet rs12 = pr12.executeQuery();
			System.out.println("MA LOAI PHONG" + "\t" + "TEN LOAI PHONG" + "\t" + "\t" + "GIA");
			while (rs12.next()) {
				String mp = rs12.getString("maLoaiPhong");
				String mlp = rs12.getString("tenLoaiPhong");
				Double g = rs12.getDouble("gia");
				System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + g);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// SAP XEP LOAI PHONG THEO GIA TANG DAN***************
	public void sapxepLoaiPhong_giaTang() {
		String sql11 = "select * from LOAIPHONG ORDER BY gia";
		try {
			PreparedStatement pr11 = con.prepareStatement(sql11);
			ResultSet rs11 = pr11.executeQuery();
			System.out.println("MA LOAI PHONG" + "\t" + "TEN LOAI PHONG" + "\t" + "\t" + "GIA");
			while (rs11.next()) {
				String mp = rs11.getString("maLoaiPhong");
				String mlp = rs11.getString("tenLoaiPhong");
				Double g = rs11.getDouble("gia");
				System.out.println(mp + "\t" + "\t" + mlp + "\t" + "\t" + g);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// THEM LOAI PHONG MOI***************************
	public void themloaiPhong() {
		String sql13 = "insert into LOAIPHONG(maLoaiPhong,tenLoaiPhong,gia)" + "values(?,?,?)";
		PreparedStatement pr = null;
		try {
			pr = con.prepareStatement(sql13);
			String mlp = Validate2.checkMaLP(scanner, "NHAP MA LOAI PHONG CAN THEM MOI : ");
			pr.setString(1, "L" + mlp);
			System.out.println("NHAP TEN LOAI PHONG PHONG CAN THEM MOI : ");
			String tlp = scanner.nextLine();
			pr.setString(2, tlp);
			double g = Validate2.check_Gia(scanner);
			pr.setDouble(3, g);
			int check = pr.executeUpdate();
			if (check != 0) {
				System.out.println("INTSERT LOAI PHONG MOI THANH CONG");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// UPDATE LOAI PHONG THEO MA LOAI PHONG*************
	public void updateLoaiPhong_maLoaiPhong() throws SQLException {
		System.out.println("NHAP MA LOAI PHONG CAN UPDATE: ");
		String updateMLP = scanner.nextLine();
		updateMLP = Validate2.check_TrungMLP1(updateMLP);
		String sql17 = "update LoaiPhong set tenLoaiPhong=?, gia=? where maLoaiPhong=?";
		try {
			PreparedStatement pr17 = con.prepareStatement(sql17);
			System.out.println("NHAP TEN LOAI PHONG : ");
			String ten = scanner.nextLine();
			pr17.setString(1, ten);
			double g = Validate2.check_Gia(scanner);
			pr17.setDouble(2, g);
			pr17.setString(3, "L" + updateMLP);
			int rowUpdate = pr17.executeUpdate();
			if (rowUpdate != 0)
				System.out.println("update thanh cong ma loai phong " + updateMLP + " trong bang MA LOAI PHONG ");
			else {
				System.out.println("khong tim thay ma loai phong can update");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// XOA LOAI PHONG THEO MA LOAI PHONG***********
	public void deleteLoaiPhong_mlp() {
		System.out.println("NHAP MA LOAI PHONG CAN XOA : ");
		String deleteMLP = scanner.nextLine();
		String sql16 = "Delete from loaiPhong where maLoaiPhong=?";
		deletePhong_mlp(deleteMLP);
		try {
			PreparedStatement pr16 = con.prepareStatement(sql16);
			pr16.setString(1, "L" + deleteMLP);
			int rowDeleted = pr16.executeUpdate();
			if (rowDeleted != 0)
				System.out.println("Da xoa thanh cong ma phong " + deleteMLP + " trong bang MA LOAI PHONG");
			else
				System.out.println("Khong tim thay ma loai phong can xoa trong bang MA LOAI PHONG");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// XOA PHONG THEO MA LOAI PHONG***********
	public void deletePhong_mlp(String mlp) {
		String sql14 = "Delete from Phong where maLoaiPhong=?";
		try {
			PreparedStatement pr14 = con.prepareStatement(sql14);
			pr14.setString(1, "L" + mlp);
			int rowDeleted = pr14.executeUpdate();
			if (rowDeleted != 0)
				System.out.println("Da xoa thanh cong ma phong " + mlp + " trong bang MA PHONG");
			else
				System.out.println("Khong co " + mlp + " trong bang MA PHONG ");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
