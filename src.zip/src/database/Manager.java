package database;

import java.sql.SQLException;
import java.util.Scanner;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import Functions.Validate;

public class Manager {

	public static void main(String[] args) {
		try {
			run();
		} catch (SQLServerException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
		//	JDBCUtil.close(con);
		}	
	}

	static void run() throws SQLServerException, SQLException {
		Validate help = new Validate();
		MainMenu menu = new MainMenu();
		Scanner scanner = new Scanner(System.in);
		boolean run = true;
			while (run) {
				System.out.println("=======QUẢN LÝ KHÁCH SẠN ALABATRAP======");
				System.out.println("CÁC CHỨC NĂNG CỦA HỆ THỐNG:");
				System.out.println("1.KHÁCH HÀNG");
				System.out.println("2.PHÒNG VÀ LOẠI PHÒNG");
				System.out.println("3.ĐẶT PHÒNG VÀ THANH TOÁN");
				System.out.println("4.YÊU CẦU CỦA KHÁCH HÀNG");
				System.out.println("5.DOANH THU");
				System.out.println("6.THOÁT");
				System.out.println("XIN MỜI NHẬP CHỨC NĂNG:");
				int choice = help.checkCuPhap(1, 6, scanner);
				System.out.println("================================");
				switch (choice) {
				case 1:
					menu.Phim1();
					break;
				case 2:
					menu.Phim2();
					break;
				case 3:
					menu.Phim3();
					break;
				case 4:
					menu.Phim4();
					break;
				case 5:
					menu.Phim5();
					break;
				default:
					run = false;
					System.out.println("=======THOÁT HỆ THỐNG======");
					break;
				}
			}
	}
}
