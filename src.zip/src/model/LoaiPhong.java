package model;

public class LoaiPhong {
	private String maLoaiPhong;
	private String tenLoaiPhong;
	private float gia;
	
	public LoaiPhong() {
	}

	public LoaiPhong(String maLoaiPhong, String tenLoaiPhong, float gia) {
		this.maLoaiPhong = maLoaiPhong;
		this.tenLoaiPhong = tenLoaiPhong;
		this.gia = gia;
	}

	public String getMaLoaiPhong() {
		return maLoaiPhong;
	}

	public void setMaLoaiPhong(String maLoaiPhong) {
		this.maLoaiPhong = maLoaiPhong;
	}

	public String getTenLoaiPhong() {
		return tenLoaiPhong;
	}

	public void setTenLoaiPhong(String tenLoaiPhong) {
		this.tenLoaiPhong = tenLoaiPhong;
	}

	public float getGia() {
		return gia;
	}

	public void setGia(float gia) {
		this.gia = gia;
	}

	@Override
	public String toString() {
		return "LoaiPhong [MaLoaiPhong: " + maLoaiPhong + "\t, TenLoaiPhong: " + tenLoaiPhong + "\t, Gia: " + gia + "]";
	}
	
	
}
