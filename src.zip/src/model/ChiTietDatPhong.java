package model;

import java.sql.Date;

public class ChiTietDatPhong {
	private int maChiTiet;
	private String maDatPhong;
	private String maPhong;
	private Date ngayCheckIn;
	private Date ngayCheckOut;
	private float thanhTien;
	private boolean trangThai;
	
	public ChiTietDatPhong() {
	}

	public ChiTietDatPhong(int maChiTiet, String maDatPhong, String maPhong, Date ngayCheckIn, Date ngayCheckOut,
			float thanhTien, boolean trangThai) {
		this.maChiTiet = maChiTiet;
		this.maDatPhong = maDatPhong;
		this.maPhong = maPhong;
		this.ngayCheckIn = ngayCheckIn;
		this.ngayCheckOut = ngayCheckOut;
		this.thanhTien = thanhTien;
		this.trangThai = trangThai;
	}

	public int getMaChiTiet() {
		return maChiTiet;
	}

	public void setMaChiTiet(int maChiTiet) {
		this.maChiTiet = maChiTiet;
	}

	public String getMaDatPhong() {
		return maDatPhong;
	}

	public void setMaDatPhong(String maDatPhong) {
		this.maDatPhong = maDatPhong;
	}

	public String getMaPhong() {
		return maPhong;
	}

	public void setMaPhong(String maPhong) {
		this.maPhong = maPhong;
	}

	public Date getNgayCheckIn() {
		return ngayCheckIn;
	}

	public void setNgayCheckIn(Date ngayCheckIn) {
		this.ngayCheckIn = ngayCheckIn;
	}

	public Date getNgayCheckOut() {
		return ngayCheckOut;
	}

	public void setNgayCheckOut(Date ngayCheckOut) {
		this.ngayCheckOut = ngayCheckOut;
	}

	public float getThanhTien() {
		return thanhTien;
	}

	public void setThanhTien(float thanhTien) {
		this.thanhTien = thanhTien;
	}

	public boolean getTrangThai() {
		return trangThai;
	}

	public void setTrangThai(boolean trangThai) {
		this.trangThai = trangThai;
	}

	@Override
	public String toString() {
		return "ChiTietDatPhong [MaChiTiet: " + maChiTiet + "\t, MaDatPhong: " + maDatPhong + "\t, MaPhong:" + maPhong
				+ "\t, NgayCheckIn: " + ngayCheckIn + "\t, NgayCheckOut: " + ngayCheckOut + "\t, ThanhTien: " + thanhTien
				+ "\t, TrangThai:" + trangThai + "]";
	}
	
	
}
