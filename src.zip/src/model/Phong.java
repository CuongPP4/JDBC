package model;

public class Phong {
	private String maPhong;
	private String maLoaiPhong;
	private boolean trangThai;
	private String moTa;
	private int soLuongToiDa;
	public Phong() {
	}
	public Phong(String maPhong, String maLoaiPhong, boolean trangThai, String moTa, int soLuongToiDa) {
		this.maPhong = maPhong;
		this.maLoaiPhong = maLoaiPhong;
		this.trangThai = trangThai;
		this.moTa = moTa;
		this.soLuongToiDa = soLuongToiDa;
	}
	public String getMaPhong() {
		return maPhong;
	}
	public void setMaPhong(String maPhong) {
		this.maPhong = maPhong;
	}
	public String getMaLoaiPhong() {
		return maLoaiPhong;
	}
	public void setMaLoaiPhong(String maLoaiPhong) {
		this.maLoaiPhong = maLoaiPhong;
	}
	public boolean getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(boolean trangThai) {
		this.trangThai = trangThai;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	public int getSoLuongToiDa() {
		return soLuongToiDa;
	}
	public void setSoLuongToiDa(int soLuongToiDa) {
		this.soLuongToiDa = soLuongToiDa;
	}
	@Override
	public String toString() {
		return "Phong [MaPhong: " + maPhong + "\t, MaLoaiPhong: " + maLoaiPhong + "\t, TrangThai: " + trangThai + "\t, MoTa:"
				+ moTa + "\t, SoLuongToiDa: " + soLuongToiDa + "]";
	}
	
	
}
