package model;

public class SuDungPhong {
	private int maChiTiet;
	private String maKH;
	private Boolean truongPhong;
	
	public SuDungPhong() {
	}

	public SuDungPhong(int maChiTiet, String maKH, Boolean truongPhong) {
		this.maChiTiet = maChiTiet;
		this.maKH = maKH;
		this.truongPhong = truongPhong;
	}

	public int getMaChiTiet() {
		return maChiTiet;
	}

	public void setMaChiTiet(int maChiTiet) {
		this.maChiTiet = maChiTiet;
	}

	public String getMaKH() {
		return maKH;
	}

	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}

	public Boolean getTruongPhong() {
		return truongPhong;
	}

	public void setTruongPhong(Boolean truongPhong) {
		this.truongPhong = truongPhong;
	}

	@Override
	public String toString() {
		return "SuDungPhong [MaChiTiet: " + maChiTiet + "\t, MaKH: " + maKH + "\t, TruongPhong: " + truongPhong + "]";
	}
	
	
	
}
