package model;

public class KhachHang {
	private String maKH;
	private String tenKH;
	private String sdt;
	private String CCCD;
	
	public KhachHang() {
	}

	public KhachHang(String maKH, String tenKH, String sdt, String cCCD) {
		super();
		this.maKH = maKH;
		this.tenKH = tenKH;
		this.sdt = sdt;
		CCCD = cCCD;
	}

	public String getMaKH() {
		return maKH;
	}

	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}

	public String getTenKH() {
		return tenKH;
	}

	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}

	public String getSdt() {
		return sdt;
	}

	public void setSdt(String sdt) {
		this.sdt = sdt;
	}

	public String getCCCD() {
		return CCCD;
	}

	public void setCCCD(String cCCD) {
		CCCD = cCCD;
	}

	@Override
	public String toString() {
		return "KhachHang [MaKH:" + maKH + "\t, TenKH: " + tenKH + "\t, SĐT: " + sdt + "\t, CCCD: " + CCCD + "]";
	}

	
	
	
}
