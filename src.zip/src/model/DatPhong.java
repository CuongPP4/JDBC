package model;

import java.sql.Date;

public class DatPhong {
	private String maDatPhong;
	private String maKH;
	private Date ngayDat;
	private int soLuongKhach;
	private int soLuongPhong;
	public DatPhong() {
	}
	public DatPhong(String maDatPhong, String maKH, Date ngayDat, int soLuongKhach, int soLuongPhong) {
		this.maDatPhong = maDatPhong;
		this.maKH = maKH;
		this.ngayDat = ngayDat;
		this.soLuongKhach = soLuongKhach;
		this.soLuongPhong = soLuongPhong;
	}
	public String getMaDatPhong() {
		return maDatPhong;
	}
	public void setMaDatPhong(String maDatPhong) {
		this.maDatPhong = maDatPhong;
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public Date getNgayDat() {
		return ngayDat;
	}
	public void setNgayDat(Date ngayDat) {
		this.ngayDat = ngayDat;
	}
	public int getSoLuongKhach() {
		return soLuongKhach;
	}
	public void setSoLuongKhach(int soLuongKhach) {
		this.soLuongKhach = soLuongKhach;
	}
	public int getSoLuongPhong() {
		return soLuongPhong;
	}
	public void setSoLuongPhong(int soLuongPhong) {
		this.soLuongPhong = soLuongPhong;
	}
	@Override
	public String toString() {
		return "DatPhong [MaDatPhong: " + maDatPhong + "\t, MaKH: " + maKH + "\t, NgayDat: " + ngayDat + "\t, SoLuongKhach: "
				+ soLuongKhach + "\t, SoLuongPhong: " + soLuongPhong + "]";
	}
	
	
}
